listOfSubjectsWithReqPreqCSE([solving_applied_mathematics,yes,yes,yes],["1. Machine Learning","2. Advanced Machine Learning","3. Deep Learning", "4. Computer Vision", "5. Natural Language Processing" ,"6. Artificial Intelligence"]).
listOfSubjectsWithReqPreqCSE([solving_applied_mathematics,no,no,no],["Sorry! But you need atleast one of the above prerequisites to take a subject from the selected domain!"]).
listOfSubjectsWithReqPreqCSE([solving_applied_mathematics,yes,no,no],["1. Probability and random process","2. Probability nd grahical model","3. Statistical Machine Learning"]).
listOfSubjectsWithReqPreqCSE([solving_applied_mathematics,no,yes,no],["1. Machine Learning","2. Theories of Deep Learning","3. Advanced Machine Learning","4. Deep Learning","5. Linear Optimization"]).
listOfSubjectsWithReqPreqCSE([solving_applied_mathematics,no,no,yes],["1. Artificial Intelligence","2. Machine Learning in Biomedical Applications"]).
listOfSubjectsWithReqPreqCSE([solving_applied_mathematics,yes,yes,no],["1. Statistical Machine Learning","2. Linear Optimization","3. Theories of Deep Learning","4. Probabilistic Graphical Models"]).
listOfSubjectsWithReqPreqCSE([solving_applied_mathematics,no,yes,yes],["1. Machine Learning","2. Theories of Deep Learning","3. Advanced Machine Learning","4. Deep Learning","5. Natural Language Processing","6. Artificial Intelligence"]).
listOfSubjectsWithReqPreqCSE([solving_applied_mathematics,yes,no,yes],["1. Probability and random process","2. Probability nd grahical model","3. Statistical Machine Learning","4. Artificial Intelligence"]).

listOfSubjectsWithReqPreqCSE([handling_data,yes,yes,yes],["1. Database System Implementation","2. Data Mining","3. Big Data Analytics", "4. Data Warehouse", "5. Database Methods in Information Retrieval"]).
listOfSubjectsWithReqPreqCSE([handling_data,no,no,no],["Sorry! But you need atleast one of the above prerequisites to take a subject from the selected domain!"]).
listOfSubjectsWithReqPreqCSE([handling_data,yes,no,no],["1. Database System Implementation","2. Database Methods in Information Retrieval","3. Data Warehouse"]).
listOfSubjectsWithReqPreqCSE([handling_data,no,yes,no],["1.Big Data Mining in Healthcare","2. Data Mining"]).
listOfSubjectsWithReqPreqCSE([handling_data,no,no,yes],["1. Data Analytics","2. Financial Data Analytics","3. Business Intelligence","Big Data Analytics"]).
listOfSubjectsWithReqPreqCSE([handling_data,yes,yes,no],["1. Database System Implementation","2. Data Warehouse","3. Introduction to Spatial Computing","4. Data Mining"]).
listOfSubjectsWithReqPreqCSE([handling_data,no,yes,yes],["1. Data Mining","2. Big Data Analytics","3. Web Intelligence and Big Data Analytics","4. Information integration and application"]).
listOfSubjectsWithReqPreqCSE([handling_data,yes,no,yes],["1. Data Mining","2. Distributed Data Mining","3. Data Warehouse","4. Business Intelligence and Data Warehousing"]).

listOfSubjectsWithReqPreqCSE([cyber_security_and_ethical_hacking,yes,yes],["1. Theory of Modern Cryptography","2. Fundations of Computer Security","3. Ethical Hacking","4. Network Security","5. Applied Cryptography"]).
listOfSubjectsWithReqPreqCSE([cyber_security_and_ethical_hacking,yes,no],["1. Topics is Cryptanalysis","2. Topics in Computer Security","3. Network Security","4. Network Anonymity and Privacy"]).

listOfSubjectsWithReqPreqCSE([mobile_computing_and_andriod_development,yes,yes],["1. Mobile Computing","2. Smart Sensing for internet of Things","3. Mobile and Cellular Network Security","4. Advanced Mobile Computing"]).
listOfSubjectsWithReqPreqCSE([mobile_computing_and_andriod_development,yes,no],["1. Cellular Data Networks","2. Network Security","3. Network Anonymity and Privacy"]).
listOfSubjectsWithReqPreqCSE([mobile_computing_and_andriod_development,no,yes],["1. Distributed Systems","2. Programming Cloud Services for mobile Applications"]).
listOfSubjectsWithReqPreqCSE([mobile_computing_and_andriod_development,no,no],["Sorry! But you need atleast one of the above prerequisites to take a subject from the selected domain!"]).

listOfSubjectsWithReqPreqCSE([theoritical_computer_science,yes,yes],["1. Randomnized Algorithm","2. Game Theory","3. Analysis and design of Algorithms","4. Quantum Computing"]).



listOfSubjectsWithReqPreqECE([cyber_physical_systems,yes,yes],["1. Wireless Communications","2. Wireless system implementation","3. Mobile Computing","4. Radar Systems"]).
listOfSubjectsWithReqPreqECE([cyber_physical_systems,no,no],["Sorry! But you need atleast one of the above prerequisites to take a subject from the selected domain!"]).
listOfSubjectsWithReqPreqECE([cyber_physical_systems,yes,no],["1. Wireless Communications","2. Wireless system implementation","3. Wireless Networks","4. Optical and Wireless Convergence for Beyond 5G and IoT"]).
listOfSubjectsWithReqPreqECE([cyber_physical_systems,no,yes],["1. Mobile Computing","2. Networked Control Systems"]).

listOfSubjectsWithReqPreqECE([machine_learning,yes,yes,yes],["1. Statistical Signal Processing","2. Probabilistic Graphical Models","3. Digital Image Processing","4. Speech and Audio Processing","5. Advanced Machine Learning"]).
listOfSubjectsWithReqPreqECE([machine_learning,yes,no,yes],["1. Statistical Signal Processing","2. Speech Recognition","3. Digital Image Processing","4. Speech and Audio Processing"]).
listOfSubjectsWithReqPreqECE([machine_learning,yes,yes,no],["1. Statistical Signal Processing","2. Speech Recognition","3. Digital Image Processing","4. Speech and Audio Processing"]).
listOfSubjectsWithReqPreqECE([machine_learning,yes,no,no],["Sorry! But you need atleast one of the above prerequisites to take a subject from the selected domain!"]).

listOfSubjectsWithReqPreqECE([vlsi_embedded_system,yes,yes],["1. Digital Verilog Design","2. Solid State Device","3. Advanced embedded system","4. Analog CMOS"]).



displayListOfSubject([]).

displayListOfSubject([H|T],L):-
	Y is L+1,
	write(H),
	nl,
	displayListOfSubject(T,Y).



suggestSubjectCSE(solving_applied_mathematics,Ans1,Ans2,Ans3):-
	write('System : You might like to take the following subjects as elective as per your solving_applied_mathematics interest choice:'),nl,
	listOfSubjectsWithReqPreqCSE([solving_applied_mathematics,Ans1,Ans2,Ans3],ListOfSubjects),nl,
	(displayListOfSubject(ListOfSubjects,0);true),nl.

suggestSubjectCSE(handling_data,Ans1,Ans2,Ans3):-
	write('System : You might like to take the following subjects as elective as per your handling_data domain choice:'),nl,
	listOfSubjectsWithReqPreqCSE([handling_data,Ans1,Ans2,Ans3],ListOfSubjects),nl,
	(displayListOfSubject(ListOfSubjects,0);true),nl.

suggestSubjectCSE(cyber_security_and_ethical_hacking,Ans1,Ans2):-
	write('System : You might like to take the following subjects as elective as per your cyber_security_and_ethical_hacking domain choice:'),nl,
	listOfSubjectsWithReqPreqCSE([cyber_security_and_ethical_hacking,Ans1,Ans2],ListOfSubjects),nl,
	(displayListOfSubject(ListOfSubjects,0);true),nl.

suggestSubjectCSE(mobile_computing_and_andriod_development,Ans1,Ans2):-
	write('System : You might like to take the following subjects as elective as per your mobile_computing_and_andriod_development domain choice:'),nl,
	listOfSubjectsWithReqPreqCSE([mobile_computing_and_andriod_development,Ans1,Ans2],ListOfSubjects),nl,
	(displayListOfSubject(ListOfSubjects,0);true),nl.

suggestSubjectCSE(theoritical_computer_science,Ans1,Ans2):-
	write('System : You might like to take the following subjects as elective as per your theoritical_computer_science domain choice:'),nl,
	listOfSubjectsWithReqPreqCSE([theoritical_computer_science,Ans1,Ans2],ListOfSubjects),nl,
	(displayListOfSubject(ListOfSubjects,0);true),nl.




suggestSubjectECE(vlsi_embedded_system,Ans1,Ans2):-
	write('System : You might like to take the following subjects as elective as per your vlsi_embedded_system domain choice:'),nl,
	listOfSubjectsWithReqPreqECE([vlsi_embedded_system,Ans1,Ans2],ListOfSubjects),nl,
	(displayListOfSubject(ListOfSubjects,0);true),nl.

suggestSubjectECE(machine_learning,Ans1,Ans2,Ans3):-
	write('System : You might like to take the following subjects as elective as per your machine_learning domain choice:'),nl,
	listOfSubjectsWithReqPreqECE([machine_learning,Ans1,Ans2,Ans3],ListOfSubjects),nl,
	(displayListOfSubject(ListOfSubjects,0);true),nl.

suggestSubjectECE(cyber_physical_systems,Ans1,Ans2):-
	write('System : You might like to take the following subjects as elective as per your cyber_physical_systems domain choice:'),nl,
	listOfSubjectsWithReqPreqECE([cyber_physical_systems,Ans1,Ans2],ListOfSubjects),nl,
	(displayListOfSubject(ListOfSubjects,0);true),nl.



checkPrequisiteCSE(solving_applied_mathematics):-
	option1SAM(Opt1),
	option2SAM(Opt2),
	option3SAM(Opt3),
	suggestSubjectCSE(solving_applied_mathematics,Opt1,Opt2,Opt3).

checkPrequisiteCSE(handling_data):-
    option1HD(Opt1),
	option2HD(Opt2),
	option3HD(Opt3),
	suggestSubjectCSE(handling_data,Opt1,Opt2,Opt3).

checkPrequisiteCSE(cyber_security_and_ethical_hacking):-
    option1CSEH(Opt1),
	(Opt1 == no->
	 	write("System : Sorry! But you need Networking as a pre-requisite to pursue subjects in cyber_security_and_ethical_hacking domain."),nl
	;
	(Opt1 == yes->
        option2CSEH(Opt2),
		suggestSubjectCSE(cyber_security_and_ethical_hacking,Opt1,Opt2)
	)).

checkPrequisiteCSE(mobile_computing_and_andriod_development):-
    option1MC(Opt1),
	option2MC(Opt2),
	suggestSubjectCSE(mobile_computing_and_andriod_development,Opt1,Opt2).

checkPrequisiteCSE(theoritical_computer_science):-
    option1TCS(Opt1),
	(Opt1 == no->
	 	write("System : Sorry! But you need Data Structure as a pre-requisite to pursue subjects in theoritical_computer_science domain."),nl
	;
	(Opt1 == yes->
        option2TCS(Opt2),
		(Opt2 = no->
			write("System : Sorry! But you need Discrete Maths as a pre-requisite to pursue subjects in theoritical_computer_science domain."),nl
		;
		(Opt2 ==yes->
			suggestSubjectCSE(theoritical_computer_science,Opt1,Opt2)
		))
	)).



checkPrequisiteECE(vlsi_embedded_system):-
    option1VES(Opt1),
	(Opt1 == no->
	 	write("System : Sorry! But you need Data Structure as a pre-requisite to pursue subjects in vlsi_embedded_system domain."),nl
	;
	(Opt1 == yes->
        option2VES(Opt2),
		(Opt2 = no->
			write("System : Sorry! But you need Discrete Maths as a pre-requisite to pursue subjects in vlsi_embedded_system domain."),nl
		;
		(Opt2 == yes->
			suggestSubjectECE(vlsi_embedded_system,Opt1,Opt2)
		))
	)).

checkPrequisiteECE(machine_learning):-
    option1ML(Opt1),
	(Opt1 == no->
	 	write("System : Sorry! But you need Signal and System as a pre-requisite to pursue subjects in machine_learning domain."),nl
	;
	(Opt1 == yes->
        option2ML(Opt2),
        option3ML(Opt3),
		suggestSubjectECE(machine_learning,Opt1,Opt2,Opt3)
	)).

checkPrequisiteECE(cyber_physical_systems):-
    option1CPS(Opt1),
    option2CPS(Opt2),
	suggestSubjectECE(cyber_physical_systems,Opt1,Opt2).



domainInterestCSE([]).

domainInterestCSE([H|T]):-
    (H == solving_applied_mathematics->
        solving_applied_mathematics(Ans),
        (Ans == yes->
            checkPrequisiteCSE(H),
		    true
        ;
        (Ans == yes->
            true
        ))
	;
	(H == handling_data->
        handling_data(Ans),
        (Ans == yes->
            checkPrequisiteCSE(H),
		    true
        ;
        (Ans == yes->
            true
        ))
    ;
    (H == cyber_security_and_ethical_hacking->
        cyber_security_and_ethical_hacking(Ans),
        (Ans == yes->
            checkPrequisiteCSE(H),
		    true
        ;
        (Ans == yes->
            true
        ))
    ;
    (H == mobile_computing_and_andriod_development->
        mobile_computing_and_andriod_development(Ans),
        (Ans == yes->
            checkPrequisiteCSE(H),
		    true
        ;
        (Ans == yes->
            true
        ))
    ;
    (H == theoritical_computer_science->
        theoritical_computer_science(Ans),
        (Ans == yes->
            checkPrequisiteCSE(H),
		    true
        ;
        (Ans == yes->
            true
        ))
	))))),
    domainInterestCSE(T).
	
domainInterestCSE([H|T]):-
	domainInterestCSE(T).



domainInterestECE([]).

domainInterestECE([H|T]):-
    (H == vlsi_embedded_system->
        vlsi_embedded_system(Ans),
        (Ans == yes->
            checkPrequisiteECE(H),
		    true
        ;
        (Ans == yes->
            true
        ))
	;
	(H == machine_learning->
        machine_learning(Ans),
        (Ans == yes->
            checkPrequisiteECE(H),
		    true
        ;
        (Ans == yes->
            true
        ))
    ;
    (H == cyber_physical_systems->
        cyber_physical_systems(Ans),
        (Ans == yes->
            checkPrequisiteECE(H),
		    true
        ;
        (Ans == yes->
            true
        ))
	))),
    domainInterestECE(T).

domainInterestECE([H|T]):-
	domainInterestECE(T).



start():-
	write('.........................MTech Elective Advisory System............................'),nl,
	consult('Users/amritaaash/AI_Assignment_5.pl'),
	branchName(Branch),
	(Branch == mtechCSE->
		mainMtechCSE(mtechCSE),
		true
	;
	(Branch == mtechECE->
		mainMtechECE(mtechECE),
		true
    ;
	(Branch == mtechCB->
		mainMtechCB(mtechCB),
		true
	))).



mainMtechCSE(mtechCSE):-
	nb_setval(counter, 0),
	domainInterestCSE([solving_applied_mathematics,handling_data,cyber_security_and_ethical_hacking,mobile_computing_and_andriod_development,theoritical_computer_science]),
	nb_getval(counter, CounterValue),
	(CounterValue == 0->
		write("System : If you have not been suggested an elective then you must select anyone of the above interest domains as all subjects of mtechCSE lie within them."),nl,
		true
	;
	(CounterValue == 1->
		true
	)),
	write('System : Thank You! Hope that the suggestions provided to you will turn out to be fruitful.').



mainMtechECE(mtechECE):-
	nb_setval(counter, 0),
	domainInterestECE([vlsi_embedded_system,machine_learning,cyber_physical_systems]),
	nb_getval(counter, CounterValue),
	(CounterValue == 0->
		write("System : If you have not been suggested an elective then you must select anyone of the above interest domains as all subjects of mtechECE lie within them."),nl,
		true
	;
	(CounterValue == 1->
		true
	)),
    write('System : Thank You! Hope that the suggestions provided to you will turn out to be fruitful.').
	


mainMtechCB(mtechCB):-
	write("System : You can pursue your elective subjects from the below list:- "),nl,
	write("1. Computational Gastronomy
		2. Machine Learning in Biomedical Applications
		3. Computing for Medicine
		4. Network Biology
		5. Computational MetaGenomics").