assertFacts([],Place,[]):-
	%if Row1 is empty i.e no destination/source then distance of place-place is 0
	assert(roaddist(Place,Place,0)).

assertFacts([_|RemPlace],Place2,[_|RemDist]):-
	%executed when Place1 and Place2 are identical, here we simply call the next place
	assertFacts(RemPlace,Place2,RemDist).




checkAssert(X,X):-  
	roaddist(X,X,0),!. %already asserted
checkAssert(X,X):- 
	assert(roaddist(X,X,0)),













startDFSSearch(City1,City2):-
	append([],[City1],Stack),
	dfs(City1, City2, Stack).


dfs(C2,C2,Stack):-
	write("Road Route taken using depth first search is: "),
	listOfPlaces(Stack).


dfs(C1,C2,Stack):-
	roaddist(C1,C2,_),
	append(Stack,[C2],NewStack),
	dfs(C2,C2,NewStack).


dfs(C1,C2,Stack):-
	roaddist(NewCity,C2,_),
	not(member(NewCity, Stack)),
	append(Stack,[NewCity], NewStack),
	dfs(NewCity, C2, NewStack),!.

















distance("Agartala","Ahmedabad",3305).
distance("Agartala","Bangalore",3824).
distance("Agartala","Bhubaneshwar",2286).
distance("Agartala","Bombay",3593).
distance("Agartala","Calcutta",1863).
distance("Agartala","Chandigarh",2998).
distance("Agartala","Cochin",4304).
distance("Agartala","Delhi",2708).
distance("Agartala","Hyderabad",3330).
distance("Agartala","Indore",2891).
distance("Agartala","Jaipur",2801).
distance("Agartala","Kanpur",2281).
distance("Agartala","Lucknow",2252).
distance("Agartala","Madras",3493).
distance("Agartala","Nagpur",2696).
distance("Agartala","Nasik",3365).
distance("Agartala","Panjim",3507).
distance("Agartala","Patna",1681).
distance("Agartala","Pondicherry",3661).
distance("Agartala","Pune",3442).
distance("Agra","Ahmedabad",878).
distance("Agra","Bangalore",1848).
distance("Agra","Bhubaneshwar",1578).
distance("Agra","Bombay",1202).
distance("Agra","Calcutta",1300).
distance("Agra","Chandigarh",448).
distance("Agra","Cochin",2278).
distance("Agra","Delhi",200).
distance("Agra","Hyderabad",1246).
distance("Agra","Indore",591).
distance("Agra","Jaipur",230).
distance("Agra","Kanpur",290).
distance("Agra","Lucknow",369).
distance("Agra","Madras",2048).
distance("Agra","Nagpur",770).
distance("Agra","Nasik",1005).
distance("Agra","Panjim",1715).
distance("Agra","Patna",885).
distance("Agra","Pondicherry",2210).
distance("Agra","Pune",1214).
distance("Ahmedabad","Ahmedabad",-).
distance("Ahmedabad","Bangalore",1490).
distance("Ahmedabad","Bhubaneshwar",1697).
distance("Ahmedabad","Bombay",552).
distance("Ahmedabad","Calcutta",2068).
distance("Ahmedabad","Chandigarh",1157).
distance("Ahmedabad","Cochin",1845).
distance("Ahmedabad","Delhi",911).
distance("Ahmedabad","Hyderabad",1436).
distance("Ahmedabad","Indore",442).
distance("Ahmedabad","Jaipur",648).
distance("Ahmedabad","Kanpur",1168).
distance("Ahmedabad","Lucknow",1247).
distance("Ahmedabad","Madras",1821).
distance("Ahmedabad","Nagpur",965).
distance("Ahmedabad","Nasik",504).
distance("Ahmedabad","Panjim",1165).
distance("Ahmedabad","Patna",1656).
distance("Ahmedabad","Pondicherry",1818).
distance("Ahmedabad","Pune",664).
distance("Allahabad","Ahmedabad",1251).
distance("Allahabad","Bangalore",1686).
distance("Allahabad","Bhubaneshwar",1090).
distance("Allahabad","Bombay",1457).
distance("Allahabad","Calcutta",817).
distance("Allahabad","Chandigarh",912).
distance("Allahabad","Cochin",2216).
distance("Allahabad","Delhi",650).
distance("Allahabad","Hyderabad",1084).
distance("Allahabad","Indore",803).
distance("Allahabad","Jaipur",713).
distance("Allahabad","Kanpur",193).
distance("Allahabad","Lucknow",234).
distance("Allahabad","Madras",2011).
distance("Allahabad","Nagpur",608).
distance("Allahabad","Nasik",1155).
distance("Allahabad","Panjim",1419).
distance("Allahabad","Patna",402).
distance("Allahabad","Pondicherry",1077).
distance("Allahabad","Pune",1364).
distance("Amritsar","Ahmedabad",1356).
distance("Amritsar","Bangalore",2496).
distance("Amritsar","Bhubaneshwar",2224).
distance("Amritsar","Bombay",1849).
distance("Amritsar","Calcutta",1919).
distance("Amritsar","Chandigarh",239).
distance("Amritsar","Cochin",3163).
distance("Amritsar","Delhi",445).
distance("Amritsar","Hyderabad",1892).
distance("Amritsar","Indore",1258).
distance("Amritsar","Jaipur",706).
distance("Amritsar","Kanpur",926).
distance("Amritsar","Lucknow",939).
distance("Amritsar","Madras",2688).
distance("Amritsar","Nagpur",1416).
distance("Amritsar","Nasik",1665).
distance("Amritsar","Panjim",2237).
distance("Amritsar","Patna",1531).
distance("Amritsar","Pondicherry",2856).
distance("Amritsar","Pune",1862).
distance("Asansol","Ahmedabad",1842).
distance("Asansol","Bangalore",2187).
distance("Asansol","Bhubaneshwar",523).
distance("Asansol","Bombay",2040).
distance("Asansol","Calcutta",226).
distance("Asansol","Chandigarh",1503).
distance("Asansol","Cochin",2544).
distance("Asansol","Delhi",1262).
distance("Asansol","Hyderabad",1693).
distance("Asansol","Indore",1394).
distance("Asansol","Jaipur",1304).
distance("Asansol","Kanpur",789).
distance("Asansol","Lucknow",825).
distance("Asansol","Madras",1857).
distance("Asansol","Nagpur",1122).
distance("Asansol","Nasik",1746).
distance("Asansol","Panjim",2300).
distance("Asansol","Patna",395).
distance("Asansol","Pondicherry",2024).
distance("Asansol","Pune",1955).
distance("Bangalore","Ahmedabad",1490).
distance("Bangalore","Bangalore",-).
distance("Bangalore","Bhubaneshwar",1538).
distance("Bangalore","Bombay",1013).
distance("Bangalore","Calcutta",1961).
distance("Bangalore","Chandigarh",2296).
distance("Bangalore","Cochin",512).
distance("Bangalore","Delhi",2049).
distance("Bangalore","Hyderabad",563).
distance("Bangalore","Indore",1601).
distance("Bangalore","Jaipur",2005).
distance("Bangalore","Kanpur",1855).
distance("Bangalore","Lucknow",1934).
distance("Bangalore","Madras",331).
distance("Bangalore","Nagpur",1078).
distance("Bangalore","Nasik",1035).
distance("Bangalore","Panjim",440).
distance("Bangalore","Patna",2071).
distance("Bangalore","Pondicherry",328).
distance("Bangalore","Pune",826).
distance("Baroda","Ahmedabad",119).
distance("Baroda","Bangalore",1408).
distance("Baroda","Bhubaneshwar",1604).
distance("Baroda","Bombay",433).
distance("Baroda","Calcutta",1937).
distance("Baroda","Chandigarh",1181).
distance("Baroda","Cochin",1763).
distance("Baroda","Delhi",1151).
distance("Baroda","Hyderabad",1127).
distance("Baroda","Indore",379).
distance("Baroda","Jaipur",789).
distance("Baroda","Kanpur",1230).
distance("Baroda","Lucknow",1311).
distance("Baroda","Madras",1739).
distance("Baroda","Nagpur",774).
distance("Baroda","Nasik",457).
distance("Baroda","Panjim",1158).
distance("Baroda","Patna",1582).
distance("Baroda","Pondicherry",1735).
distance("Baroda","Pune",545).
distance("Bhopal","Ahmedabad",523).
distance("Bhopal","Bangalore",1148).
distance("Bhopal","Bhubaneshwar",1162).
distance("Bhopal","Bombay",778).
distance("Bhopal","Calcutta",1495).
distance("Bhopal","Chandigarh",988).
distance("Bhopal","Cochin",1995).
distance("Bhopal","Delhi",742).
distance("Bhopal","Hyderabad",808).
distance("Bhopal","Indore",191).
distance("Bhopal","Jaipur",596).
distance("Bhopal","Kanpur",585).
distance("Bhopal","Lucknow",664).
distance("Bhopal","Madras",1604).
distance("Bhopal","Nagpur",352).
distance("Bhopal","Nasik",605).
distance("Bhopal","Panjim",1143).
distance("Bhopal","Patna",1016).
distance("Bhopal","Pondicherry",1772).
distance("Bhopal","Pune",814).
distance("Bhubaneshwar","Ahmedabad",1647).
distance("Bhubaneshwar","Bangalore",1538).
distance("Bhubaneshwar","Bhubaneshwar",-).
distance("Bhubaneshwar","Bombay",1679).
distance("Bhubaneshwar","Calcutta",423).
distance("Bhubaneshwar","Chandigarh",2026).
distance("Bhubaneshwar","Cochin",1895).
distance("Bhubaneshwar","Delhi",1713).
distance("Bhubaneshwar","Hyderabad",1044).
distance("Bhubaneshwar","Indore",1355).
distance("Bhubaneshwar","Jaipur",1758).
distance("Bhubaneshwar","Kanpur",1283).
distance("Bhubaneshwar","Lucknow",1254).
distance("Bhubaneshwar","Madras",1207).
distance("Bhubaneshwar","Nagpur",830).
distance("Bhubaneshwar","Nasik",1516).
distance("Bhubaneshwar","Panjim",1455).
distance("Bhubaneshwar","Patna",862).
distance("Bhubaneshwar","Pondicherry",1375).
distance("Bhubaneshwar","Pune",1587).
distance("Bombay","Ahmedabad",552).
distance("Bombay","Bangalore",1013).
distance("Bombay","Bhubaneshwar",1678).
distance("Bombay","Bombay",-).
distance("Bombay","Calcutta",2012).
distance("Bombay","Chandigarh",1645).
distance("Bombay","Cochin",1368).
distance("Bombay","Delhi",1404).
distance("Bombay","Hyderabad",729).
distance("Bombay","Indore",589).
distance("Bombay","Jaipur",1148).
distance("Bombay","Kanpur",1278).
distance("Bombay","Lucknow",1366).
distance("Bombay","Madras",1344).
distance("Bombay","Nagpur",849).
distance("Bombay","Nasik",197).
distance("Bombay","Panjim",584).
distance("Bombay","Patna",1856).
distance("Bombay","Pondicherry",1452).
distance("Bombay","Pune",184).
distance("Calcutta","Ahmedabad",2068).
distance("Calcutta","Bangalore",1461).
distance("Calcutta","Bhubaneshwar",423).
distance("Calcutta","Bombay",2012).
distance("Calcutta","Calcutta",-).
distance("Calcutta","Chandigarh",1721).
distance("Calcutta","Cochin",2318).
distance("Calcutta","Delhi",1474).
distance("Calcutta","Hyderabad",1467).
distance("Calcutta","Indore",1620).
distance("Calcutta","Jaipur",1530).
distance("Calcutta","Kanpur",1010).
distance("Calcutta","Lucknow",1089).
distance("Calcutta","Madras",1160).
distance("Calcutta","Nagpur",1163).
distance("Calcutta","Nasik",1849).
distance("Calcutta","Panjim",974).
distance("Calcutta","Patna",621).
distance("Calcutta","Pondicherry",1798).
distance("Calcutta","Pune",2058).
distance("Calicut","Ahmedabad",1648).
distance("Calicut","Bangalore",520).
distance("Calicut","Bhubaneshwar",1923).
distance("Calicut","Bombay",1171).
distance("Calicut","Calcutta",2346).
distance("Calicut","Chandigarh",2741).
distance("Calicut","Cochin",222).
distance("Calicut","Delhi",2494).
distance("Calicut","Hyderabad",910).
distance("Calicut","Indore",1998).
distance("Calicut","Jaipur",2523).
distance("Calicut","Kanpur",2260).
distance("Calicut","Lucknow",2339).
distance("Calicut","Madras",715).
distance("Calicut","Nagpur",1483).
distance("Calicut","Nasik",1193).
distance("Calicut","Panjim",576).
distance("Calicut","Patna",2476).
distance("Calicut","Pondicherry",566).
distance("Calicut","Pune",984).
distance("Chandigarh","Ahmedabad",1157).
distance("Chandigarh","Bangalore",2296).
distance("Chandigarh","Bhubaneshwar",2026).
distance("Chandigarh","Bombay",1645).
distance("Chandigarh","Calcutta",1721).
distance("Chandigarh","Chandigarh",-).
distance("Chandigarh","Cochin",1965).
distance("Chandigarh","Delhi",248).
distance("Chandigarh","Hyderabad",1693).
distance("Chandigarh","Indore",1052).
distance("Chandigarh","Jaipur",507).
distance("Chandigarh","Kanpur",661).
distance("Chandigarh","Lucknow",740).
distance("Chandigarh","Madras",2489).
distance("Chandigarh","Nagpur",1217).
distance("Chandigarh","Nasik",1466).
distance("Chandigarh","Panjim",2028).
distance("Chandigarh","Patna",1332).
distance("Chandigarh","Pondicherry",2657).
distance("Chandigarh","Pune",1663).
distance("Cochin","Ahmedabad",1845).
distance("Cochin","Bangalore",512).
distance("Cochin","Bhubaneshwar",1895).
distance("Cochin","Bombay",1368).
distance("Cochin","Calcutta",2318).
distance("Cochin","Chandigarh",1965).
distance("Cochin","Cochin",-).
distance("Cochin","Delhi",2718).
distance("Cochin","Hyderabad",1090).
distance("Cochin","Indore",1804).
distance("Cochin","Jaipur",2745).
distance("Cochin","Kanpur",2385).
distance("Cochin","Lucknow",2572).
distance("Cochin","Madras",687).
distance("Cochin","Nagpur",1608).
distance("Cochin","Nasik",1390).
distance("Cochin","Panjim",798).
distance("Cochin","Patna",2601).
distance("Cochin","Pondicherry",530).
distance("Cochin","Pune",1181).
distance("Coimbatore","Ahmedabad",1669).
distance("Coimbatore","Bangalore",333).
distance("Coimbatore","Bhubaneshwar",1633).
distance("Coimbatore","Bombay",1192).
distance("Coimbatore","Calcutta",2057).
distance("Coimbatore","Chandigarh",2669).
distance("Coimbatore","Cochin",195).
distance("Coimbatore","Delhi",2412).
distance("Coimbatore","Hyderabad",912).
distance("Coimbatore","Indore",1964).
distance("Coimbatore","Jaipur",2369).
distance("Coimbatore","Kanpur",2218).
distance("Coimbatore","Lucknow",2297).
distance("Coimbatore","Madras",426).
distance("Coimbatore","Nagpur",1441).
distance("Coimbatore","Nasik",1214).
distance("Coimbatore","Panjim",800).
distance("Coimbatore","Patna",2434).
distance("Coimbatore","Pondicherry",410).
distance("Coimbatore","Pune",1005).
distance("Delhi","Ahmedabad",911).
distance("Delhi","Bangalore",2049).
distance("Delhi","Bhubaneshwar",1713).
distance("Delhi","Bombay",1404).
distance("Delhi","Calcutta",1474).
distance("Delhi","Chandigarh",248).
distance("Delhi","Cochin",2718).
distance("Delhi","Delhi",-).
distance("Delhi","Hyderabad",1477).
distance("Delhi","Indore",806).
distance("Delhi","Jaipur",263).
distance("Delhi","Kanpur",481).
distance("Delhi","Lucknow",499).
distance("Delhi","Madras",2243).
distance("Delhi","Nagpur",971).
distance("Delhi","Nasik",1220).
distance("Delhi","Panjim",1782).
distance("Delhi","Patna",1086).
distance("Delhi","Pondicherry",2411).
distance("Delhi","Pune",1417).
distance("Gwalior","Ahmedabad",919).
distance("Gwalior","Bangalore",1734).
distance("Gwalior","Bhubaneshwar",1486).
distance("Gwalior","Bombay",1085).
distance("Gwalior","Calcutta",1224).
distance("Gwalior","Chandigarh",462).
distance("Gwalior","Cochin",1881).
distance("Gwalior","Delhi",315).
distance("Gwalior","Hyderabad",1132).
distance("Gwalior","Indore",497).
distance("Gwalior","Jaipur",351).
distance("Gwalior","Kanpur",280).
distance("Gwalior","Lucknow",359).
distance("Gwalior","Madras",1928).
distance("Gwalior","Nagpur",656).
distance("Gwalior","Nasik",891).
distance("Gwalior","Panjim",1467).
distance("Gwalior","Patna",809).
distance("Gwalior","Pondicherry",2096).
distance("Gwalior","Pune",1100).
distance("Hubli","Ahmedabad",1101).
distance("Hubli","Bangalore",391).
distance("Hubli","Bhubaneshwar",1620).
distance("Hubli","Bombay",614).
distance("Hubli","Calcutta",2032).
distance("Hubli","Chandigarh",2101).
distance("Hubli","Cochin",774).
distance("Hubli","Delhi",1854).
distance("Hubli","Hyderabad",486).
distance("Hubli","Indore",1060).
distance("Hubli","Jaipur",1060).
distance("Hubli","Kanpur",1772).
distance("Hubli","Lucknow",1851).
distance("Hubli","Madras",683).
distance("Hubli","Nagpur",995).
distance("Hubli","Nasik",646).
distance("Hubli","Panjim",190).
distance("Hubli","Patna",1998).
distance("Hubli","Pondicherry",653).
distance("Hubli","Pune",437).
distance("Hyderabad","Ahmedabad",1436).
distance("Hyderabad","Bangalore",563).
distance("Hyderabad","Bhubaneshwar",1044).
distance("Hyderabad","Bombay",729).
distance("Hyderabad","Calcutta",1467).
distance("Hyderabad","Chandigarh",1693).
distance("Hyderabad","Cochin",1090).
distance("Hyderabad","Delhi",1447).
distance("Hyderabad","Hyderabad",-).
distance("Hyderabad","Indore",999).
distance("Hyderabad","Jaipur",1404).
distance("Hyderabad","Kanpur",1253).
distance("Hyderabad","Lucknow",1332).
distance("Hyderabad","Madras",699).
distance("Hyderabad","Nagpur",476).
distance("Hyderabad","Nasik",754).
distance("Hyderabad","Panjim",765).
distance("Hyderabad","Patna",1469).
distance("Hyderabad","Pondicherry",865).
distance("Hyderabad","Pune",545).
distance("Imphal","Ahmedabad",3240).
distance("Imphal","Bangalore",3677).
distance("Imphal","Bhubaneshwar",2139).
distance("Imphal","Bombay",3446).
distance("Imphal","Calcutta",1717).
distance("Imphal","Chandigarh",2851).
distance("Imphal","Cochin",4156).
distance("Imphal","Delhi",2561).
distance("Imphal","Hyderabad",3283).
distance("Imphal","Indore",2744).
distance("Imphal","Jaipur",2654).
distance("Imphal","Kanpur",2134).
distance("Imphal","Lucknow",2105).
distance("Imphal","Madras",3326).
distance("Imphal","Nagpur",2549).
distance("Imphal","Nasik",3218).
distance("Imphal","Panjim",3360).
distance("Imphal","Patna",1534).
distance("Imphal","Pondicherry",3614).
distance("Imphal","Pune",3295).
distance("Indore","Ahmedabad",442).
distance("Indore","Bangalore",1601).
distance("Indore","Bhubaneshwar",1355).
distance("Indore","Bombay",589).
distance("Indore","Calcutta",1620).
distance("Indore","Chandigarh",1052).
distance("Indore","Cochin",1804).
distance("Indore","Delhi",806).
distance("Indore","Hyderabad",999).
distance("Indore","Indore",-).
distance("Indore","Jaipur",405).
distance("Indore","Kanpur",689).
distance("Indore","Lucknow",768).
distance("Indore","Madras",1795).
distance("Indore","Nagpur",445).
distance("Indore","Nasik",414).
distance("Indore","Panjim",1115).
distance("Indore","Patna",1205).
distance("Indore","Pondicherry",1963).
distance("Indore","Pune",623).
distance("Jabalpur","Ahmedabad",901).
distance("Jabalpur","Bangalore",1335).
distance("Jabalpur","Bhubaneshwar",1087).
distance("Jabalpur","Bombay",1143).
distance("Jabalpur","Calcutta",1167).
distance("Jabalpur","Chandigarh",1046).
distance("Jabalpur","Cochin",1885).
distance("Jabalpur","Delhi",800).
distance("Jabalpur","Hyderabad",733).
distance("Jabalpur","Indore",859).
distance("Jabalpur","Jaipur",845).
distance("Jabalpur","Kanpur",543).
distance("Jabalpur","Lucknow",584).
distance("Jabalpur","Madras",1529).
distance("Jabalpur","Nagpur",257).
distance("Jabalpur","Nasik",943).
distance("Jabalpur","Panjim",1088).
distance("Jabalpur","Patna",736).
distance("Jabalpur","Pondicherry",1697).
distance("Jabalpur","Pune",1003).
distance("Jaipur","Ahmedabad",648).
distance("Jaipur","Bangalore",2005).
distance("Jaipur","Bhubaneshwar",1758).
distance("Jaipur","Bombay",1148).
distance("Jaipur","Calcutta",1530).
distance("Jaipur","Chandigarh",507).
distance("Jaipur","Cochin",2745).
distance("Jaipur","Delhi",263).
distance("Jaipur","Hyderabad",1404).
distance("Jaipur","Indore",405).
distance("Jaipur","Jaipur",-).
distance("Jaipur","Kanpur",517).
distance("Jaipur","Lucknow",598).
distance("Jaipur","Madras",2200).
distance("Jaipur","Nagpur",928).
distance("Jaipur","Nasik",1248).
distance("Jaipur","Panjim",2496).
distance("Jaipur","Patna",1115).
distance("Jaipur","Pondicherry",2368).
distance("Jaipur","Pune",1371).
distance("Jamshedpur","Ahmedabad",1225).
distance("Jamshedpur","Bangalore",1690).
distance("Jamshedpur","Bhubaneshwar",422).
distance("Jamshedpur","Bombay",1916).
distance("Jamshedpur","Calcutta",268).
distance("Jamshedpur","Chandigarh",1602).
distance("Jamshedpur","Cochin",2710).
distance("Jamshedpur","Delhi",1356).
distance("Jamshedpur","Hyderabad",1578).
distance("Jamshedpur","Indore",1477).
distance("Jamshedpur","Jaipur",1387).
distance("Jamshedpur","Kanpur",867).
distance("Jamshedpur","Lucknow",1121).
distance("Jamshedpur","Madras",1629).
distance("Jamshedpur","Nagpur",1102).
distance("Jamshedpur","Nasik",1788).
distance("Jamshedpur","Panjim",2229).
distance("Jamshedpur","Patna",473).
distance("Jamshedpur","Pondicherry",1797).
distance("Jamshedpur","Pune",1997).
distance("Jullundur","Ahmedabad",1285).
distance("Jullundur","Bangalore",2416).
distance("Jullundur","Bhubaneshwar",2413).
distance("Jullundur","Bombay",1778).
distance("Jullundur","Calcutta",1869).
distance("Jullundur","Chandigarh",154).
distance("Jullundur","Cochin",3082).
distance("Jullundur","Delhi",375).
distance("Jullundur","Hyderabad",1821).
distance("Jullundur","Indore",1171).
distance("Jullundur","Jaipur",891).
distance("Jullundur","Kanpur",855).
distance("Jullundur","Lucknow",868).
distance("Jullundur","Madras",2617).
distance("Jullundur","Nagpur",1354).
distance("Jullundur","Nasik",1591).
distance("Jullundur","Panjim",2146).
distance("Jullundur","Patna",1460).
distance("Jullundur","Pondicherry",2785).
distance("Jullundur","Pune",1791).
distance("Kanpur","Ahmedabad",1168).
distance("Kanpur","Bangalore",1855).
distance("Kanpur","Bhubaneshwar",1283).
distance("Kanpur","Bombay",1278).
distance("Kanpur","Calcutta",1010).
distance("Kanpur","Chandigarh",661).
distance("Kanpur","Cochin",2385).
distance("Kanpur","Delhi",481).
distance("Kanpur","Hyderabad",1253).
distance("Kanpur","Indore",689).
distance("Kanpur","Jaipur",517).
distance("Kanpur","Kanpur",-).
distance("Kanpur","Lucknow",79).
distance("Kanpur","Madras",2049).
distance("Kanpur","Nagpur",777).
distance("Kanpur","Nasik",1103).
distance("Kanpur","Panjim",1813).
distance("Kanpur","Patna",596).
distance("Kanpur","Pondicherry",2217).
distance("Kanpur","Pune",1312).
distance("Kolhapur","Ahmedabad",911).
distance("Kolhapur","Bangalore",484).
distance("Kolhapur","Bhubaneshwar",1622).
distance("Kolhapur","Bombay",426).
distance("Kolhapur","Calcutta",2045).
distance("Kolhapur","Chandigarh",1910).
distance("Kolhapur","Cochin",934).
distance("Kolhapur","Delhi",1664).
distance("Kolhapur","Hyderabad",578).
distance("Kolhapur","Indore",870).
distance("Kolhapur","Jaipur",1518).
distance("Kolhapur","Kanpur",1779).
distance("Kolhapur","Lucknow",1858).
distance("Kolhapur","Madras",910).
distance("Kolhapur","Nagpur",1050).
distance("Kolhapur","Nasik",456).
distance("Kolhapur","Panjim",254).
distance("Kolhapur","Patna",2047).
distance("Kolhapur","Pondicherry",907).
distance("Kolhapur","Pune",247).
distance("Lucknow","Ahmedabad",1247).
distance("Lucknow","Bangalore",1934).
distance("Lucknow","Bhubaneshwar",1254).
distance("Lucknow","Bombay",1366).
distance("Lucknow","Calcutta",1089).
distance("Lucknow","Chandigarh",740).
distance("Lucknow","Cochin",2572).
distance("Lucknow","Delhi",499).
distance("Lucknow","Hyderabad",1332).
distance("Lucknow","Indore",768).
distance("Lucknow","Jaipur",598).
distance("Lucknow","Kanpur",79).
distance("Lucknow","Lucknow",-).
distance("Lucknow","Madras",2128).
distance("Lucknow","Nagpur",856).
distance("Lucknow","Nasik",1182).
distance("Lucknow","Panjim",1883).
distance("Lucknow","Patna",566).
distance("Lucknow","Pondicherry",2296).
distance("Lucknow","Pune",1391).
distance("Ludhiana","Ahmedabad",1220).
distance("Ludhiana","Bangalore",2358).
distance("Ludhiana","Bhubaneshwar",2088).
distance("Ludhiana","Bombay",1770).
distance("Ludhiana","Calcutta",1783).
distance("Ludhiana","Chandigarh",105).
distance("Ludhiana","Cochin",3027).
distance("Ludhiana","Delhi",310).
distance("Ludhiana","Hyderabad",1756).
distance("Ludhiana","Indore",1115).
distance("Ludhiana","Jaipur",570).
distance("Ludhiana","Kanpur",790).
distance("Ludhiana","Lucknow",803).
distance("Ludhiana","Madras",2552).
distance("Ludhiana","Nagpur",1280).
distance("Ludhiana","Nasik",1528).
distance("Ludhiana","Panjim",2091).
distance("Ludhiana","Patna",1395).
distance("Ludhiana","Pondicherry",2720).
distance("Ludhiana","Pune",1726).
distance("Madras","Ahmedabad",1821).
distance("Madras","Bangalore",331).
distance("Madras","Bhubaneshwar",1207).
distance("Madras","Bombay",1344).
distance("Madras","Calcutta",1630).
distance("Madras","Chandigarh",2489).
distance("Madras","Cochin",687).
distance("Madras","Delhi",2243).
distance("Madras","Hyderabad",699).
distance("Madras","Indore",1795).
distance("Madras","Jaipur",2200).
distance("Madras","Kanpur",2049).
distance("Madras","Lucknow",2128).
distance("Madras","Madras",-).
distance("Madras","Nagpur",1272).
distance("Madras","Nasik",1366).
distance("Madras","Panjim",909).
distance("Madras","Patna",2096).
distance("Madras","Pondicherry",168).
distance("Madras","Pune",1157).
distance("Madurai","Ahmedabad",1922).
distance("Madurai","Bangalore",432).
distance("Madurai","Bhubaneshwar",1687).
distance("Madurai","Bombay",1458).
distance("Madurai","Calcutta",2110).
distance("Madurai","Chandigarh",2785).
distance("Madurai","Cochin",326).
distance("Madurai","Delhi",2539).
distance("Madurai","Hyderabad",995).
distance("Madurai","Indore",2091).
distance("Madurai","Jaipur",2496).
distance("Madurai","Kanpur",2345).
distance("Madurai","Lucknow",2424).
distance("Madurai","Madras",480).
distance("Madurai","Nagpur",1568).
distance("Madurai","Nasik",1467).
distance("Madurai","Panjim",872).
distance("Madurai","Patna",2561).
distance("Madurai","Pondicherry",333).
distance("Madurai","Pune",1238).
distance("Meerut","Ahmedabad",1092).
distance("Meerut","Bangalore",2072).
distance("Meerut","Bhubaneshwar",1822).
distance("Meerut","Bombay",1468).
distance("Meerut","Calcutta",1497).
distance("Meerut","Chandigarh",381).
distance("Meerut","Cochin",2741).
distance("Meerut","Delhi",66).
distance("Meerut","Hyderabad",1470).
distance("Meerut","Indore",815).
distance("Meerut","Jaipur",327).
distance("Meerut","Kanpur",537).
distance("Meerut","Lucknow",453).
distance("Meerut","Madras",2266).
distance("Meerut","Nagpur",994).
distance("Meerut","Nasik",1242).
distance("Meerut","Panjim",1805).
distance("Meerut","Patna",934).
distance("Meerut","Pondicherry",2434).
distance("Meerut","Pune",1440).
distance("Nagpur","Ahmedabad",965).
distance("Nagpur","Bangalore",1078).
distance("Nagpur","Bhubaneshwar",830).
distance("Nagpur","Bombay",849).
distance("Nagpur","Calcutta",1163).
distance("Nagpur","Chandigarh",1217).
distance("Nagpur","Cochin",1608).
distance("Nagpur","Delhi",971).
distance("Nagpur","Hyderabad",476).
distance("Nagpur","Indore",445).
distance("Nagpur","Jaipur",928).
distance("Nagpur","Kanpur",777).
distance("Nagpur","Lucknow",856).
distance("Nagpur","Madras",1272).
distance("Nagpur","Nagpur",-).
distance("Nagpur","Nasik",700).
distance("Nagpur","Panjim",1247).
distance("Nagpur","Patna",993).
distance("Nagpur","Pondicherry",1440).
distance("Nagpur","Pune",909).
distance("Nasik","Ahmedabad",504).
distance("Nasik","Bangalore",1036).
distance("Nasik","Bhubaneshwar",1516).
distance("Nasik","Bombay",197).
distance("Nasik","Calcutta",1849).
distance("Nasik","Chandigarh",1466).
distance("Nasik","Cochin",1390).
distance("Nasik","Delhi",1220).
distance("Nasik","Hyderabad",754).
distance("Nasik","Indore",414).
distance("Nasik","Jaipur",1246).
distance("Nasik","Kanpur",1103).
distance("Nasik","Lucknow",1182).
distance("Nasik","Madras",1366).
distance("Nasik","Nagpur",700).
distance("Nasik","Nasik",-).
distance("Nasik","Panjim",701).
distance("Nasik","Patna",1679).
distance("Nasik","Pondicherry",1363).
distance("Nasik","Pune",209).
distance("Panjim","Ahmedabad",1165).
distance("Panjim","Bangalore",440).
distance("Panjim","Bhubaneshwar",1455).
distance("Panjim","Bombay",584).
distance("Panjim","Calcutta",974).
distance("Panjim","Chandigarh",2028).
distance("Panjim","Cochin",798).
distance("Panjim","Delhi",1782).
distance("Panjim","Hyderabad",765).
distance("Panjim","Indore",1115).
distance("Panjim","Jaipur",2496).
distance("Panjim","Kanpur",1813).
distance("Panjim","Lucknow",1883).
distance("Panjim","Madras",909).
distance("Panjim","Nagpur",1247).
distance("Panjim","Nasik",701).
distance("Panjim","Panjim",-).
distance("Panjim","Patna",1804).
distance("Panjim","Pondicherry",739).
distance("Panjim","Pune",501).
distance("Patna","Ahmedabad",1656).
distance("Patna","Bangalore",2071).
distance("Patna","Bhubaneshwar",862).
distance("Patna","Bombay",1856).
distance("Patna","Calcutta",621).
distance("Patna","Chandigarh",1332).
distance("Patna","Cochin",2601).
distance("Patna","Delhi",1086).
distance("Patna","Hyderabad",1489).
distance("Patna","Indore",1205).
distance("Patna","Jaipur",1115).
distance("Patna","Kanpur",595).
distance("Patna","Lucknow",566).
distance("Patna","Madras",2096).
distance("Patna","Nagpur",993).
distance("Patna","Nasik",1679).
distance("Patna","Panjim",1804).
distance("Patna","Patna",-).
distance("Patna","Pondicherry",2264).
distance("Patna","Pune",1738).
distance("Pondicherry","Ahmedabad",1818).
distance("Pondicherry","Bangalore",328).
distance("Pondicherry","Bhubaneshwar",1375).
distance("Pondicherry","Bombay",1452).
distance("Pondicherry","Calcutta",1798).
distance("Pondicherry","Chandigarh",2657).
distance("Pondicherry","Cochin",530).
distance("Pondicherry","Delhi",2411).
distance("Pondicherry","Hyderabad",867).
distance("Pondicherry","Indore",1963).
distance("Pondicherry","Jaipur",2368).
distance("Pondicherry","Kanpur",2217).
distance("Pondicherry","Lucknow",2296).
distance("Pondicherry","Madras",168).
distance("Pondicherry","Nagpur",1440).
distance("Pondicherry","Nasik",1363).
distance("Pondicherry","Panjim",739).
distance("Pondicherry","Patna",2264).
distance("Pondicherry","Pondicherry",-).
distance("Pondicherry","Pune",1154).
distance("Pune","Ahmedabad",664).
distance("Pune","Bangalore",826).
distance("Pune","Bhubaneshwar",1587).
distance("Pune","Bombay",184).
distance("Pune","Calcutta",2058).
distance("Pune","Chandigarh",1663).
distance("Pune","Cochin",1181).
distance("Pune","Delhi",1417).
distance("Pune","Hyderabad",545).
distance("Pune","Indore",623).
distance("Pune","Jaipur",1371).
distance("Pune","Kanpur",1312).
distance("Pune","Lucknow",1391).
distance("Pune","Madras",1157).
distance("Pune","Nagpur",909).
distance("Pune","Nasik",209).
distance("Pune","Panjim",501).
distance("Pune","Patna",1738).
distance("Pune","Pondicherry",1154).
distance("Pune","Pune",-).
distance("Ranchi","Ahmedabad",1781).
distance("Ranchi","Bangalore",2098).
distance("Ranchi","Bhubaneshwar",560).
distance("Ranchi","Bombay",1816).
distance("Ranchi","Calcutta",414).
distance("Ranchi","Chandigarh",1480).
distance("Ranchi","Cochin",2455).
distance("Ranchi","Delhi",1214).
distance("Ranchi","Hyderabad",1434).
distance("Ranchi","Indore",1333).
distance("Ranchi","Jaipur",1243).
distance("Ranchi","Kanpur",723).
distance("Ranchi","Lucknow",912).
distance("Ranchi","Madras",1767).
distance("Ranchi","Nagpur",958).
distance("Ranchi","Nasik",1615).
distance("Ranchi","Panjim",1630).
distance("Ranchi","Patna",302).
distance("Ranchi","Pondicherry",1935).
distance("Ranchi","Pune",1675).
distance("Shillong","Ahmedabad",2839).
distance("Shillong","Bangalore",3242).
distance("Shillong","Bhubaneshwar",1640).
distance("Shillong","Bombay",3011).
distance("Shillong","Calcutta",1281).
distance("Shillong","Chandigarh",2416).
distance("Shillong","Cochin",3599).
distance("Shillong","Delhi",2126).
distance("Shillong","Hyderabad",1309).
distance("Shillong","Indore",2309).
distance("Shillong","Jaipur",2229).
distance("Shillong","Kanpur",1699).
distance("Shillong","Lucknow",1670).
distance("Shillong","Madras",2911).
distance("Shillong","Nagpur",2114).
distance("Shillong","Nasik",2800).
distance("Shillong","Panjim",2925).
distance("Shillong","Patna",1019).
distance("Shillong","Pondicherry",3079).
distance("Shillong","Pune",2860).
distance("Shimla","Ahmedabad",1256).
distance("Shimla","Bangalore",2395).
distance("Shimla","Bhubaneshwar",2127).
distance("Shimla","Bombay",1753).
distance("Shimla","Calcutta",1839).
distance("Shimla","Chandigarh",99).
distance("Shimla","Cochin",3056).
distance("Shimla","Delhi",365).
distance("Shimla","Hyderabad",1812).
distance("Shimla","Indore",1171).
distance("Shimla","Jaipur",636).
distance("Shimla","Kanpur",846).
distance("Shimla","Lucknow",659).
distance("Shimla","Madras",2588).
distance("Shimla","Nagpur",1336).
distance("Shimla","Nasik",1567).
distance("Shimla","Panjim",2130).
distance("Shimla","Patna",1434).
distance("Shimla","Pondicherry",2759).
distance("Shimla","Pune",1782).
distance("Surat","Ahmedabad",263).
distance("Surat","Bangalore",1264).
distance("Surat","Bhubaneshwar",1579).
distance("Surat","Bombay",301).
distance("Surat","Calcutta",1912).
distance("Surat","Chandigarh",1325).
distance("Surat","Cochin",1593).
distance("Surat","Delhi",1182).
distance("Surat","Hyderabad",983).
distance("Surat","Indore",607).
distance("Surat","Jaipur",932).
distance("Surat","Kanpur",1296).
distance("Surat","Lucknow",1375).
distance("Surat","Madras",1695).
distance("Surat","Nagpur",749).
distance("Surat","Nasik",262).
distance("Surat","Panjim",913).
distance("Surat","Patna",1742).
distance("Surat","Pondicherry",1789).
distance("Surat","Pune",412).
distance("Trivandrum","Ahmedabad",2197).
distance("Trivandrum","Bangalore",696).
distance("Trivandrum","Bhubaneshwar",1953).
distance("Trivandrum","Bombay",1376).
distance("Trivandrum","Calcutta",2376).
distance("Trivandrum","Chandigarh",3051).
distance("Trivandrum","Cochin",218).
distance("Trivandrum","Delhi",1950).
distance("Trivandrum","Hyderabad",1261).
distance("Trivandrum","Indore",2156).
distance("Trivandrum","Jaipur",2782).
distance("Trivandrum","Kanpur",2611).
distance("Trivandrum","Lucknow",2690).
distance("Trivandrum","Madras",748).
distance("Trivandrum","Nagpur",1834).
distance("Trivandrum","Nasik",1742).
distance("Trivandrum","Panjim",792).
distance("Trivandrum","Patna",2827).
distance("Trivandrum","Pondicherry",622).
distance("Trivandrum","Pune",1533).
distance("Varanasi","Ahmedabad",1373).
distance("Varanasi","Bangalore",1791).
distance("Varanasi","Bhubaneshwar",968).
distance("Varanasi","Bombay",1597).
distance("Varanasi","Calcutta",695).
distance("Varanasi","Chandigarh",1032).
distance("Varanasi","Cochin",2331).
distance("Varanasi","Delhi",745).
distance("Varanasi","Hyderabad",1189).
distance("Varanasi","Indore",925).
distance("Varanasi","Jaipur",835).
distance("Varanasi","Kanpur",315).
distance("Varanasi","Lucknow",286).
distance("Varanasi","Madras",1985).
distance("Varanasi","Nagpur",713).
distance("Varanasi","Nasik",1399).
distance("Varanasi","Panjim",1524).
distance("Varanasi","Patna",280).
distance("Varanasi","Pondicherry",2153).
distance("Varanasi","Pune",1459).
distance("Vijayawada","Ahmedabad",1705).
distance("Vijayawada","Bangalore",637).
distance("Vijayawada","Bhubaneshwar",775).
distance("Vijayawada","Bombay",973).
distance("Vijayawada","Calcutta",1198).
distance("Vijayawada","Chandigarh",1959).
distance("Vijayawada","Cochin",1174).
distance("Vijayawada","Delhi",1716).
distance("Vijayawada","Hyderabad",269).
distance("Vijayawada","Indore",1255).
distance("Vijayawada","Jaipur",1660).
distance("Vijayawada","Kanpur",1519).
distance("Vijayawada","Lucknow",1598).
distance("Vijayawada","Madras",432).
distance("Vijayawada","Nagpur",742).
distance("Vijayawada","Nasik",1428).
distance("Vijayawada","Panjim",876).
distance("Vijayawada","Patna",1664).
distance("Vijayawada","Pondicherry",598).
distance("Vijayawada","Pune",842).
distance("Vishakapatnam","Ahmedabad",1815).
distance("Vishakapatnam","Bangalore",1093).
distance("Vishakapatnam","Bhubaneshwar",445).
distance("Vishakapatnam","Bombay",1754).
distance("Vishakapatnam","Calcutta",868).
distance("Vishakapatnam","Chandigarh",2127).
distance("Vishakapatnam","Cochin",1449).
distance("Vishakapatnam","Delhi",1881).
distance("Vishakapatnam","Hyderabad",599).
distance("Vishakapatnam","Indore",1433).
distance("Vishakapatnam","Jaipur",1838).
distance("Vishakapatnam","Kanpur",1687).
distance("Vishakapatnam","Lucknow",1765).
distance("Vishakapatnam","Madras",762).
distance("Vishakapatnam","Nagpur",910).
distance("Vishakapatnam","Nasik",1596).
distance("Vishakapatnam","Panjim",1206).
distance("Vishakapatnam","Patna",1334).
distance("Vishakapatnam","Pondicherry",930).
distance("Vishakapatnam","Pune",1658).

%direct_path
% here,the rule path is for direct path and has attributes:
% start,goal,path and the distance between start and goal
path(A, B, [A, B], X) :-
    distance(A, B, X).
%Indirect_path
% here,the rule path is for indirect path and has attributes:
% start,goal,path and the distance between start and goal
path(A, B, PathAB, Length) :-
    distance(A, C, X),
    path(C, B, PathCB, LengthCB),
    PathAB = [A | PathCB],
    Length is X + LengthCB.
    %compared with distance fact
    %again path rule called for other cities
    %here, A(start) get added to the path list with the rest Cb list
    %here the value of start to one city(not goal) is added to the next city distance(length)
find_paths(A, B) :-
    path(A, B, Path, Length),
    printPath(Path),
    writef(' and Total distance travelled is : %d\n', [Length]),
    fail.
%finds the path between City A and City B
printPath([]).
printPath([X]) :-
   !, write(X).
printPath([X|T]) :-
    write(X),
    write(' to '),
    printPath(T).
%prints the path for the cities moved through.











startBFSSearch(Start,Goal) :-
    empty_nb_set(Closed),
    empty_heap(Empty_open),
    heuristic(Start, Goal, H),
    state_record(Start, nil, 0, H, H, First_record),
    add_to_heap(First_record, Empty_open, Open),
    path(Open,Closed, Goal).


state_record(State, Parent, G, H, F, [State, Parent, G, H, F]).

path(Open,_,_) :-
    empty_heap(Open),
    write("graph searched, no solution found").

path(Open, Closed, Goal) :-
	write("h3"),
    delete_from_heap(First_record, Open, _),
    state_record(State, _, _, _, _, First_record),
    State = Goal,
    write('Solution path is: '), nl,
    printsolution(First_record, Closed).

path(Open, Closed, Goal) :-
	write("h4"),
    delete_from_heap(First_record, Open, Rest_of_open),
    (bagof(Child, moves(First_record, Open, Closed, Child, Goal), Children);Children = []),
    insert_list(Children, Rest_of_open, New_open),
    add_to_set(First_record, Closed, New_closed),
    path(New_open, New_closed, Goal),!.

    
moves(State_record, Open, Closed,Child, Goal) :-
	write("h5"),
    state_record(State, _, G, _,_, State_record),
    mov(State, Next),
    % not(unsafe(Next)),
    state_record(Next, _, _, _, _, Test),
    not(member_sort_queue(Test, Open)),
    not(member_set(Test, Closed)),
    G_new is G + 1,
    heuristic(Next, Goal, H),
    F is G_new + H,
    state_record(Next, State, G_new, H, F, Child).

   
insert_list([], L, L).
insert_list([State | Tail], L, New_L) :-
	write("h6"),
    add_to_heap(State, L, L2),
    insert_list(Tail, L2, New_L).


printsolution(Next_record, _):-
	write("h8"),
    state_record(State, nil, _, _,_, Next_record),
    write(State), nl.

printsolution(Next_record, Closed) :-
	write("h7"),
    state_record(State, Parent, _, _,_, Next_record),
    state_record(Parent, _, _, _, _, Parent_record),
    member_set(Parent_record, Closed),
    printsolution(Parent_record, Closed),
    write(State), nl.






















































heuristic(agartala,agartala,0).
heuristic(agra,agartala,1382).
heuristic(ahmedabad,agartala,1908).
heuristic(allahabad,agartala,971).
heuristic(amritsar,agartala,1830).
heuristic(asansol,agartala,438).
heuristic(bangalore,agartala,1880).
heuristic(baroda,agartala,1857).
heuristic(bhopal,agartala,1415).
heuristic(bhubaneshwar,agartala,687).
heuristic(bombay,agartala,1974).
heuristic(calcutta,agartala,329).
heuristic(calicut,agartala,2155).
heuristic(chandigarh,agartala,1623).
heuristic(cochin,agartala,2219).
heuristic(coimbatore,agartala,2080).
heuristic(delhi,agartala,1499).
heuristic(gwalior,agartala,1347).
heuristic(hubli,agartala,1933).
heuristic(hyderabad,agartala,1513).
heuristic(imphal,agartala,289).
heuristic(indore,agartala,1578).
heuristic(jabalpur,agartala,1157).
heuristic(jaipur,agartala,1589).
heuristic(jamshedpur,agartala,531).
heuristic(jullundur,agartala,1756).
heuristic(kanpur,agartala,1140).
heuristic(kolhapur,agartala,1944).
heuristic(lucknow,agartala,1091).
heuristic(ludhiana,agartala,1712).
heuristic(madras,agartala,1664).
heuristic(madurai,agartala,2083).
heuristic(meerut,agartala,1462).
heuristic(nagpur,agartala,1287).
heuristic(nasik,agartala,1852).
heuristic(panjim,agartala,2046).
heuristic(patna,agartala,652).
heuristic(pondicherry,agartala,1792).
heuristic(pune,agartala,1899).
heuristic(ranchi,agartala,609).
heuristic(shillong,agartala,203).
heuristic(shimla,agartala,1607).
heuristic(surat,agartala,7984).
heuristic(trivandrum,agartala,2288).
heuristic(varanasi,agartala,853).
heuristic(vijayawada,agartala,1378).
heuristic(vishakapatnam,agartala,1072).
heuristic(agartala,agra,1382).
heuristic(agra,agra,0).
heuristic(ahmedabad,agra,715).
heuristic(allahabad,agra,427).
heuristic(amritsar,agra,581).
heuristic(asansol,agra,979).
heuristic(bangalore,agra,1579).
heuristic(baroda,agra,728).
heuristic(bhopal,agra,439).
heuristic(bhubaneshwar,agra,1106).
heuristic(bombay,agra,1041).
heuristic(calcutta,agra,1162).
heuristic(calicut,agra,1786).
heuristic(chandigarh,agra,413).
heuristic(cochin,agra,1926).
heuristic(coimbatore,agra,1801).
heuristic(delhi,agra,181).
heuristic(gwalior,agra,109).
heuristic(hubli,agra,1347).
heuristic(hyderabad,agra,1092).
heuristic(imphal,agra,1612).
heuristic(indore,agra,540).
heuristic(jabalpur,agra,487).
heuristic(jaipur,agra,218).
heuristic(jamshedpur,agra,957).
heuristic(jullundur,agra,525).
heuristic(kanpur,agra,242).
heuristic(kolhapur,agra,1227).
heuristic(lucknow,agra,292).
heuristic(ludhiana,agra,465).
heuristic(madras,agra,1584).
heuristic(madurai,agra,1918).
heuristic(meerut,agra,204).
heuristic(nagpur,agra,678).
heuristic(nasik,agra,905).
heuristic(panjim,agra,1368).
heuristic(patna,agra,729).
heuristic(pondicherry,agra,1705).
heuristic(pune,agra,1052).
heuristic(ranchi,agra,848).
heuristic(shillong,agra,1392).
heuristic(shimla,agra,444).
heuristic(surat,agra,6738).
heuristic(trivandrum,agra,2080).
heuristic(varanasi,agra,538).
heuristic(vijayawada,agra,1216).
heuristic(vishakapatnam,agra,1182).
heuristic(agartala,ahmedabad,1908).
heuristic(agra,ahmedabad,715).
heuristic(ahmedabad,ahmedabad,0).
heuristic(allahabad,ahmedabad,975).
heuristic(amritsar,ahmedabad,984).
heuristic(asansol,ahmedabad,1470).
heuristic(bangalore,ahmedabad,1235).
heuristic(baroda,ahmedabad,102).
heuristic(bhopal,ahmedabad,493).
heuristic(bhubaneshwar,ahmedabad,1403).
heuristic(bombay,ahmedabad,439).
heuristic(calcutta,ahmedabad,1618).
heuristic(calicut,ahmedabad,1352).
heuristic(chandigarh,ahmedabad,953).
heuristic(cochin,ahmedabad,1507).
heuristic(coimbatore,ahmedabad,1415).
heuristic(delhi,ahmedabad,779).
heuristic(gwalior,ahmedabad,665).
heuristic(hubli,ahmedabad,894).
heuristic(hyderabad,ahmedabad,879).
heuristic(imphal,ahmedabad,2177).
heuristic(indore,ahmedabad,338).
heuristic(jabalpur,ahmedabad,753).
heuristic(jaipur,ahmedabad,542).
heuristic(jamshedpur,ahmedabad,1395).
heuristic(jullundur,ahmedabad,980).
heuristic(kanpur,ahmedabad,870).
heuristic(kolhapur,ahmedabad,723).
heuristic(lucknow,ahmedabad,942).
heuristic(ludhiana,ahmedabad,934).
heuristic(madras,ahmedabad,1371).
heuristic(madurai,ahmedabad,1570).
heuristic(meerut,ahmedabad,842).
heuristic(nagpur,ahmedabad,701).
heuristic(nasik,ahmedabad,357).
heuristic(panjim,ahmedabad,846).
heuristic(patna,ahmedabad,1302).
heuristic(pondicherry,ahmedabad,1452).
heuristic(pune,ahmedabad,517).
heuristic(ranchi,ahmedabad,1302).
heuristic(shillong,ahmedabad,1974).
heuristic(shimla,ahmedabad,1006).
heuristic(surat,ahmedabad,6620).
heuristic(trivandrum,ahmedabad,1681).
heuristic(varanasi,ahmedabad,1088).
heuristic(vijayawada,ahmedabad,1109).
heuristic(vishakapatnam,ahmedabad,1261).
heuristic(agartala,allahabad,971).
heuristic(agra,allahabad,427).
heuristic(ahmedabad,allahabad,975).
heuristic(allahabad,allahabad,0).
heuristic(amritsar,allahabad,967).
heuristic(asansol,allahabad,555).
heuristic(bangalore,allahabad,1455).
heuristic(baroda,allahabad,945).
heuristic(bhopal,allahabad,510).
heuristic(bhubaneshwar,allahabad,706).
heuristic(bombay,allahabad,1160).
heuristic(calcutta,allahabad,735).
heuristic(calicut,allahabad,1701).
heuristic(chandigarh,allahabad,769).
heuristic(cochin,allahabad,1821).
heuristic(coimbatore,allahabad,1685).
heuristic(delhi,allahabad,579).
heuristic(gwalior,allahabad,377).
heuristic(hubli,allahabad,1320).
heuristic(hyderabad,allahabad,963).
heuristic(imphal,allahabad,1220).
heuristic(indore,allahabad,676).
heuristic(jabalpur,allahabad,317).
heuristic(jaipur,allahabad,622).
heuristic(jamshedpur,allahabad,531).
heuristic(jullundur,allahabad,900).
heuristic(kanpur,allahabad,189).
heuristic(kolhapur,allahabad,1249).
heuristic(lucknow,allahabad,179).
heuristic(ludhiana,allahabad,844).
heuristic(madras,allahabad,1383).
heuristic(madurai,allahabad,1768).
heuristic(meerut,allahabad,564).
heuristic(nagpur,allahabad,553).
heuristic(nasik,allahabad,1021).
heuristic(panjim,allahabad,1383).
heuristic(patna,allahabad,330).
heuristic(pondicherry,allahabad,1516).
heuristic(pune,allahabad,1125).
heuristic(ranchi,allahabad,421).
heuristic(shillong,allahabad,1008).
heuristic(shimla,allahabad,777).
heuristic(surat,allahabad,7154).
heuristic(trivandrum,allahabad,1954).
heuristic(varanasi,allahabad,118).
heuristic(vijayawada,allahabad,1000).
heuristic(vishakapatnam,allahabad,871).
heuristic(agartala,amritsar,1830).
heuristic(agra,amritsar,581).
heuristic(ahmedabad,amritsar,984).
heuristic(allahabad,amritsar,967).
heuristic(amritsar,amritsar,0).
heuristic(asansol,amritsar,1481).
heuristic(bangalore,amritsar,2093).
heuristic(baroda,amritsar,1051).
heuristic(bhopal,amritsar,964).
heuristic(bhubaneshwar,amritsar,1671).
heuristic(bombay,amritsar,1410).
heuristic(calcutta,amritsar,1670).
heuristic(calicut,amritsar,2269).
heuristic(chandigarh,amritsar,207).
heuristic(cochin,amritsar,2417).
heuristic(coimbatore,amritsar,2304).
heuristic(delhi,amritsar,401).
heuristic(gwalior,amritsar,683).
heuristic(hubli,amritsar,1810).
heuristic(hyderabad,amritsar,1628).
heuristic(imphal,amritsar,2012).
heuristic(indore,amritsar,996).
heuristic(jabalpur,amritsar,1066).
heuristic(jaipur,amritsar,532).
heuristic(jamshedpur,amritsar,1488).
heuristic(jullundur,amritsar,74).
heuristic(kanpur,amritsar,781).
heuristic(kolhapur,amritsar,1661).
heuristic(lucknow,amritsar,793).
heuristic(ludhiana,amritsar,123).
heuristic(madras,amritsar,2135).
heuristic(madurai,amritsar,2436).
heuristic(meerut,amritsar,403).
heuristic(nagpur,amritsar,1238).
heuristic(nasik,amritsar,1296).
heuristic(panjim,amritsar,1797).
heuristic(patna,amritsar,1203).
heuristic(pondicherry,amritsar,2248).
heuristic(pune,amritsar,1461).
heuristic(ranchi,amritsar,1379).
heuristic(shillong,amritsar,1789).
heuristic(shimla,amritsar,225).
heuristic(surat,amritsar,6192).
heuristic(trivandrum,amritsar,2582).
heuristic(varanasi,amritsar,1058).
heuristic(vijayawada,amritsar,1779).
heuristic(vishakapatnam,amritsar,1763).
heuristic(agartala,asansol,438).
heuristic(agra,asansol,979).
heuristic(ahmedabad,asansol,1470).
heuristic(allahabad,asansol,555).
heuristic(amritsar,asansol,1481).
heuristic(asansol,asansol,0).
heuristic(bangalore,asansol,1547).
heuristic(baroda,asansol,1418).
heuristic(bhopal,asansol,977).
heuristic(bhubaneshwar,asansol,398).
heuristic(bombay,asansol,1545).
heuristic(calcutta,asansol,188).
heuristic(calicut,asansol,1821).
heuristic(chandigarh,asansol,1275).
heuristic(cochin,asansol,1905).
heuristic(coimbatore,asansol,1764).
heuristic(delhi,asansol,1118).
heuristic(gwalior,asansol,931).
heuristic(hubli,asansol,1547).
heuristic(hyderabad,asansol,1130).
heuristic(imphal,asansol,716).
heuristic(indore,asansol,1139).
heuristic(jabalpur,asansol,719).
heuristic(jaipur,asansol,1176).
heuristic(jamshedpur,asansol,126).
heuristic(jullundur,asansol,1410).
heuristic(kanpur,asansol,737).
heuristic(kolhapur,asansol,1537).
heuristic(lucknow,asansol,701).
heuristic(ludhiana,asansol,1359).
heuristic(madras,asansol,1374).
heuristic(madurai,asansol,1795).
heuristic(meerut,asansol,1090).
heuristic(nagpur,asansol,858).
heuristic(nasik,asansol,1420).
heuristic(panjim,asansol,1649).
heuristic(patna,asansol,284).
heuristic(pondicherry,asansol,1509).
heuristic(pune,asansol,1476).
heuristic(ranchi,asansol,171).
heuristic(shillong,asansol,538).
heuristic(shimla,asansol,1270).
heuristic(surat,asansol,7672).
heuristic(trivandrum,asansol,1998).
heuristic(varanasi,asansol,441).
heuristic(vijayawada,asansol,1037).
heuristic(vishakapatnam,asansol,765).
heuristic(agartala,bangalore,1880).
heuristic(agra,bangalore,1579).
heuristic(ahmedabad,bangalore,1235).
heuristic(allahabad,bangalore,1455).
heuristic(amritsar,bangalore,2093).
heuristic(asansol,bangalore,1547).
heuristic(bangalore,bangalore,0).
heuristic(baroda,bangalore,1135).
heuristic(bhopal,bangalore,1143).
heuristic(bhubaneshwar,bangalore,1194).
heuristic(bombay,bangalore,844).
heuristic(calcutta,bangalore,1560).
heuristic(calicut,bangalore,275).
heuristic(chandigarh,bangalore,1976).
heuristic(cochin,bangalore,368).
heuristic(coimbatore,bangalore,229).
heuristic(delhi,bangalore,1743).
heuristic(gwalior,bangalore,1471).
heuristic(hubli,bangalore,373).
heuristic(hyderabad,bangalore,496).
heuristic(imphal,bangalore,2160).
heuristic(indore,bangalore,1098).
heuristic(jabalpur,bangalore,1159).
heuristic(jaipur,bangalore,1560).
heuristic(jamshedpur,bangalore,1421).
heuristic(jullundur,bangalore,2060).
heuristic(kanpur,bangalore,1526).
heuristic(kolhapur,bangalore,548).
heuristic(lucknow,bangalore,1580).
heuristic(ludhiana,bangalore,2001).
heuristic(madras,bangalore,290).
heuristic(madurai,bangalore,343).
heuristic(meerut,bangalore,1781).
heuristic(nagpur,bangalore,922).
heuristic(nasik,bangalore,880).
heuristic(panjim,bangalore,492).
heuristic(patna,bangalore,1610).
heuristic(pondicherry,bangalore,269).
heuristic(pune,bangalore,734).
heuristic(ranchi,bangalore,1414).
heuristic(shillong,bangalore,2049).
heuristic(shimla,bangalore,2016).
heuristic(surat,bangalore,7767).
heuristic(trivandrum,bangalore,504).
heuristic(varanasi,bangalore,1486).
heuristic(vijayawada,bangalore,510).
heuristic(vishakapatnam,bangalore,807).
heuristic(agartala,baroda,1857).
heuristic(agra,baroda,728).
heuristic(ahmedabad,baroda,102).
heuristic(allahabad,baroda,945).
heuristic(amritsar,baroda,1051).
heuristic(asansol,baroda,1418).
heuristic(bangalore,baroda,1135).
heuristic(baroda,baroda,0).
heuristic(bhopal,baroda,444).
heuristic(bhubaneshwar,baroda,1329).
heuristic(bombay,baroda,359).
heuristic(calcutta,baroda,1558).
heuristic(calicut,baroda,1259).
heuristic(chandigarh,baroda,1003).
heuristic(cochin,baroda,1413).
heuristic(coimbatore,baroda,1318).
heuristic(delhi,baroda,813).
heuristic(gwalior,baroda,664).
heuristic(hubli,baroda,798).
heuristic(hyderabad,baroda,778).
heuristic(imphal,baroda,2130).
heuristic(indore,baroda,278).
heuristic(jabalpur,baroda,699).
heuristic(jaipur,baroda,577).
heuristic(jamshedpur,baroda,1336).
heuristic(jullundur,baroda,1042).
heuristic(kanpur,baroda,857).
heuristic(kolhapur,baroda,631).
heuristic(lucknow,baroda,931).
heuristic(ludhiana,baroda,993).
heuristic(madras,baroda,1268).
heuristic(madurai,baroda,1472).
heuristic(meerut,baroda,874).
heuristic(nagpur,baroda,621).
heuristic(nasik,baroda,261).
heuristic(panjim,baroda,758).
heuristic(patna,baroda,1266).
heuristic(pondicherry,baroda,1350).
heuristic(pune,baroda,425).
heuristic(ranchi,baroda,1248).
heuristic(shillong,baroda,1932).
heuristic(shimla,baroda,1055).
heuristic(surat,baroda,6720).
heuristic(trivandrum,baroda,1587).
heuristic(varanasi,baroda,1053).
heuristic(vijayawada,baroda,1009).
heuristic(vishakapatnam,baroda,1170).
heuristic(agartala,bhopal,1415).
heuristic(agra,bhopal,439).
heuristic(ahmedabad,bhopal,493).
heuristic(allahabad,bhopal,510).
heuristic(amritsar,bhopal,964).
heuristic(asansol,bhopal,977).
heuristic(bangalore,bhopal,1143).
heuristic(baroda,bhopal,444).
heuristic(bhopal,bhopal,0).
heuristic(bhubaneshwar,bhopal,932).
heuristic(bombay,bhopal,660).
heuristic(calcutta,bhopal,1125).
heuristic(calicut,bhopal,1346).
heuristic(chandigarh,bhopal,833).
heuristic(cochin,bhopal,1486).
heuristic(coimbatore,bhopal,1363).
heuristic(delhi,bhopal,599).
heuristic(gwalior,bhopal,336).
heuristic(hubli,bhopal,910).
heuristic(hyderabad,bhopal,665).
heuristic(imphal,bhopal,1686).
heuristic(indore,bhopal,168).
heuristic(jabalpur,bhopal,260).
heuristic(jaipur,bhopal,436).
heuristic(jamshedpur,bhopal,901).
heuristic(jullundur,bhopal,924).
heuristic(kanpur,bhopal,462).
heuristic(kolhapur,bhopal,800).
heuristic(lucknow,bhopal,533).
heuristic(ludhiana,bhopal,864).
heuristic(madras,bhopal,1171).
heuristic(madurai,bhopal,1484).
heuristic(meerut,bhopal,639).
heuristic(nagpur,bhopal,291).
heuristic(nasik,bhopal,519).
heuristic(panjim,bhopal,940).
heuristic(patna,bhopal,824).
heuristic(pondicherry,bhopal,1285).
heuristic(pune,bhopal,642).
heuristic(ranchi,bhopal,809).
heuristic(shillong,bhopal,1487).
heuristic(shimla,bhopal,872).
heuristic(surat,bhopal,6974).
heuristic(trivandrum,bhopal,1643).
heuristic(varanasi,bhopal,613).
heuristic(vijayawada,bhopal,822).
heuristic(vishakapatnam,bhopal,868).
heuristic(agartala,bhubaneshwar,687).
heuristic(agra,bhubaneshwar,1106).
heuristic(ahmedabad,bhubaneshwar,1403).
heuristic(allahabad,bhubaneshwar,706).
heuristic(amritsar,bhubaneshwar,1671).
heuristic(asansol,bhubaneshwar,398).
heuristic(bangalore,bhubaneshwar,1194).
heuristic(baroda,bhubaneshwar,1329).
heuristic(bhopal,bhubaneshwar,932).
heuristic(bhubaneshwar,bhubaneshwar,0).
heuristic(bombay,bhubaneshwar,1363).
heuristic(calcutta,bhubaneshwar,366).
heuristic(calicut,bhubaneshwar,1470).
heuristic(chandigarh,bhubaneshwar,1476).
heuristic(cochin,bhubaneshwar,1539).
heuristic(coimbatore,bhubaneshwar,1400).
heuristic(delhi,bhubaneshwar,1276).
heuristic(gwalior,bhubaneshwar,1025).
heuristic(hubli,bhubaneshwar,1257).
heuristic(hyderabad,bhubaneshwar,839).
heuristic(imphal,bhubaneshwar,972).
heuristic(indore,bhubaneshwar,1067).
heuristic(jabalpur,bhubaneshwar,688).
heuristic(jaipur,bhubaneshwar,1260).
heuristic(jamshedpur,bhubaneshwar,285).
heuristic(jullundur,bhubaneshwar,1606).
heuristic(kanpur,bhubaneshwar,890).
heuristic(kolhapur,bhubaneshwar,1285).
heuristic(lucknow,bhubaneshwar,885).
heuristic(ludhiana,bhubaneshwar,1549).
heuristic(madras,bhubaneshwar,994).
heuristic(madurai,bhubaneshwar,1416).
heuristic(meerut,bhubaneshwar,1268).
heuristic(nagpur,bhubaneshwar,709).
heuristic(nasik,bhubaneshwar,1257).
heuristic(panjim,bhubaneshwar,1376).
heuristic(patna,bhubaneshwar,599).
heuristic(pondicherry,bhubaneshwar,1126).
heuristic(pune,bhubaneshwar,1271).
heuristic(ranchi,bhubaneshwar,349).
heuristic(shillong,bhubaneshwar,855).
heuristic(shimla,bhubaneshwar,1484).
heuristic(surat,bhubaneshwar,7844).
heuristic(trivandrum,bhubaneshwar,1620).
heuristic(varanasi,bhubaneshwar,634).
heuristic(vijayawada,bhubaneshwar,690).
heuristic(vishakapatnam,bhubaneshwar,389).
heuristic(agartala,bombay,1974).
heuristic(agra,bombay,1041).
heuristic(ahmedabad,bombay,439).
heuristic(allahabad,bombay,1160).
heuristic(amritsar,bombay,1410).
heuristic(asansol,bombay,1545).
heuristic(bangalore,bombay,844).
heuristic(baroda,bombay,359).
heuristic(bhopal,bombay,660).
heuristic(bhubaneshwar,bombay,1363).
heuristic(bombay,bombay,0).
heuristic(calcutta,bombay,1654).
heuristic(calicut,bombay,924).
heuristic(chandigarh,bombay,1354).
heuristic(cochin,bombay,1080).
heuristic(coimbatore,bombay,999).
heuristic(delhi,bombay,1152).
heuristic(gwalior,bombay,959).
heuristic(hubli,bombay,478).
heuristic(hyderabad,bombay,621).
heuristic(imphal,bombay,2260).
heuristic(indore,bombay,510).
heuristic(jabalpur,bombay,862).
heuristic(jaipur,bombay,921).
heuristic(jamshedpur,bombay,1443).
heuristic(jullundur,bombay,1399).
heuristic(kanpur,bombay,1120).
heuristic(kolhapur,bombay,300).
heuristic(lucknow,bombay,1192).
heuristic(ludhiana,bombay,1348).
heuristic(madras,bombay,1033).
heuristic(madurai,bombay,1163).
heuristic(meerut,bombay,1209).
heuristic(nagpur,bombay,687).
heuristic(nasik,bombay,141).
heuristic(panjim,bombay,410).
heuristic(patna,bombay,1452).
heuristic(pondicherry,bombay,1088).
heuristic(pune,bombay,119).
heuristic(ranchi,bombay,1374).
heuristic(shillong,bombay,2081).
heuristic(shimla,bombay,1404).
heuristic(surat,bombay,6935).
heuristic(trivandrum,bombay,1256).
heuristic(varanasi,bombay,1252).
heuristic(vijayawada,bombay,867).
heuristic(vishakapatnam,bombay,1108).
heuristic(agartala,calcutta,329).
heuristic(agra,calcutta,1162).
heuristic(ahmedabad,calcutta,1618).
heuristic(allahabad,calcutta,735).
heuristic(amritsar,calcutta,1670).
heuristic(asansol,calcutta,188).
heuristic(bangalore,calcutta,1560).
heuristic(baroda,calcutta,1558).
heuristic(bhopal,calcutta,1125).
heuristic(bhubaneshwar,calcutta,366).
heuristic(bombay,calcutta,1654).
heuristic(calcutta,calcutta,0).
heuristic(calicut,calcutta,1836).
heuristic(chandigarh,calcutta,1464).
heuristic(cochin,calcutta,1906).
heuristic(coimbatore,calcutta,1766).
heuristic(delhi,calcutta,1304).
heuristic(gwalior,calcutta,1109).
heuristic(hubli,calcutta,1604).
heuristic(hyderabad,calcutta,1184).
heuristic(imphal,calcutta,619).
heuristic(indore,calcutta,1282).
heuristic(jabalpur,calcutta,864).
heuristic(jaipur,calcutta,1354).
heuristic(jamshedpur,calcutta,223).
heuristic(jullundur,calcutta,1598).
heuristic(kanpur,calcutta,921).
heuristic(kolhapur,calcutta,1615).
heuristic(lucknow,calcutta,887).
heuristic(ludhiana,calcutta,1548).
heuristic(madras,calcutta,1358).
heuristic(madurai,calcutta,1779).
heuristic(meerut,calcutta,1278).
heuristic(nagpur,calcutta,970).
heuristic(nasik,calcutta,1535).
heuristic(panjim,calcutta,1716).
heuristic(patna,calcutta,471).
heuristic(pondicherry,calcutta,1489).
heuristic(pune,calcutta,1575).
heuristic(ranchi,calcutta,323).
heuristic(shillong,calcutta,488).
heuristic(shimla,calcutta,1458).
heuristic(surat,calcutta,7860).
heuristic(trivandrum,calcutta,1984).
heuristic(varanasi,calcutta,624).
heuristic(vijayawada,calcutta,1054).
heuristic(vishakapatnam,calcutta,755).
heuristic(agartala,calicut,2155).
heuristic(agra,calicut,1786).
heuristic(ahmedabad,calicut,1352).
heuristic(allahabad,calicut,1701).
heuristic(amritsar,calicut,2269).
heuristic(asansol,calicut,1821).
heuristic(bangalore,calicut,275).
heuristic(baroda,calicut,1259).
heuristic(bhopal,calicut,1346).
heuristic(bhubaneshwar,calicut,1470).
heuristic(bombay,calicut,924).
heuristic(calcutta,calicut,1836).
heuristic(calicut,calicut,0).
heuristic(chandigarh,calicut,2169).
heuristic(cochin,calicut,155).
heuristic(coimbatore,calicut,132).
heuristic(delhi,calicut,1941).
heuristic(gwalior,calicut,1681).
heuristic(hubli,calicut,461).
heuristic(hyderabad,calicut,739).
heuristic(imphal,calicut,2435).
heuristic(indore,calicut,1276).
heuristic(jabalpur,calicut,1396).
heuristic(jaipur,calicut,1742).
heuristic(jamshedpur,calicut,1695).
heuristic(jullundur,calicut,2243).
heuristic(kanpur,calicut,1757).
heuristic(kolhapur,calicut,629).
heuristic(lucknow,calicut,1816).
heuristic(ludhiana,calicut,2186).
heuristic(madras,calicut,529).
heuristic(madurai,calicut,294).
heuristic(meerut,calicut,1985).
heuristic(nagpur,calicut,1156).
heuristic(nasik,calicut,997).
heuristic(panjim,calicut,517).
heuristic(patna,calicut,1875).
heuristic(pondicherry,calicut,448).
heuristic(pune,calicut,834).
heuristic(ranchi,calicut,1685).
heuristic(shillong,calicut,2324).
heuristic(shimla,calicut,2212).
heuristic(surat,calicut,7763).
heuristic(trivandrum,calicut,332).
heuristic(varanasi,calicut,1741).
heuristic(vijayawada,calicut,784).
heuristic(vishakapatnam,calicut,1082).
heuristic(agartala,chandigarh,1623).
heuristic(agra,chandigarh,413).
heuristic(ahmedabad,chandigarh,953).
heuristic(allahabad,chandigarh,769).
heuristic(amritsar,chandigarh,207).
heuristic(asansol,chandigarh,1275).
heuristic(bangalore,chandigarh,1976).
heuristic(baroda,chandigarh,1003).
heuristic(bhopal,chandigarh,833).
heuristic(bhubaneshwar,chandigarh,1476).
heuristic(bombay,chandigarh,1354).
heuristic(calcutta,chandigarh,1464).
heuristic(calicut,chandigarh,2169).
heuristic(chandigarh,chandigarh,0).
heuristic(cochin,chandigarh,2313).
heuristic(coimbatore,chandigarh,2194).
heuristic(delhi,chandigarh,235).
heuristic(gwalior,chandigarh,521).
heuristic(hubli,chandigarh,1718).
heuristic(hyderabad,chandigarh,1496).
heuristic(imphal,chandigarh,1809).
heuristic(indore,chandigarh,895).
heuristic(jabalpur,chandigarh,898).
heuristic(jaipur,chandigarh,434).
heuristic(jamshedpur,chandigarh,1284).
heuristic(jullundur,chandigarh,134).
heuristic(kanpur,chandigarh,587).
heuristic(kolhapur,chandigarh,1581).
heuristic(lucknow,chandigarh,592).
heuristic(ludhiana,chandigarh,90).
heuristic(madras,chandigarh,1994).
heuristic(madurai,chandigarh,2317).
heuristic(meerut,chandigarh,214).
heuristic(nagpur,chandigarh,1090).
heuristic(nasik,chandigarh,1229).
heuristic(panjim,chandigarh,1720).
heuristic(patna,chandigarh,996).
heuristic(pondicherry,chandigarh,2113).
heuristic(pune,chandigarh,1389).
heuristic(ranchi,chandigarh,1176).
heuristic(shillong,chandigarh,1586).
heuristic(shimla,chandigarh,55).
heuristic(surat,chandigarh,6397).
heuristic(trivandrum,chandigarh,2473).
heuristic(varanasi,chandigarh,856).
heuristic(vijayawada,chandigarh,1628).
heuristic(vishakapatnam,chandigarh,1589).
heuristic(agartala,cochin,2219).
heuristic(agra,cochin,1926).
heuristic(ahmedabad,cochin,1507).
heuristic(allahabad,cochin,1821).
heuristic(amritsar,cochin,2417).
heuristic(asansol,cochin,1905).
heuristic(bangalore,cochin,368).
heuristic(baroda,cochin,1413).
heuristic(bhopal,cochin,1486).
heuristic(bhubaneshwar,cochin,1539).
heuristic(bombay,cochin,1080).
heuristic(calcutta,cochin,1906).
heuristic(calicut,cochin,155).
heuristic(chandigarh,cochin,2313).
heuristic(cochin,cochin,0).
heuristic(coimbatore,cochin,141).
heuristic(delhi,cochin,2083).
heuristic(gwalior,cochin,1820).
heuristic(hubli,cochin,615).
heuristic(hyderabad,cochin,859).
heuristic(imphal,cochin,2494).
heuristic(indore,cochin,1422).
heuristic(jabalpur,cochin,1522).
heuristic(jaipur,cochin,1889).
heuristic(jamshedpur,cochin,1779).
heuristic(jullundur,cochin,2390).
heuristic(kanpur,cochin,1886).
heuristic(kolhapur,cochin,784).
heuristic(lucknow,cochin,1942).
heuristic(ludhiana,cochin,2333).
heuristic(madras,cochin,559).
heuristic(madurai,cochin,202).
heuristic(meerut,cochin,2126).
heuristic(nagpur,cochin,1283).
heuristic(nasik,cochin,1151).
heuristic(panjim,cochin,673).
heuristic(patna,cochin,1977).
heuristic(pondicherry,cochin,448).
heuristic(pune,cochin,989).
heuristic(ranchi,cochin,1777).
heuristic(shillong,cochin,2395).
heuristic(shimla,cochin,2356).
heuristic(surat,cochin,7904).
heuristic(trivandrum,cochin,176).
heuristic(varanasi,cochin,1854).
heuristic(vijayawada,cochin,869).
heuristic(vishakapatnam,cochin,1150).
heuristic(agartala,coimbatore,2080).
heuristic(agra,coimbatore,1801).
heuristic(ahmedabad,coimbatore,1415).
heuristic(allahabad,coimbatore,1685).
heuristic(amritsar,coimbatore,2304).
heuristic(asansol,coimbatore,1764).
heuristic(bangalore,coimbatore,229).
heuristic(baroda,coimbatore,1318).
heuristic(bhopal,coimbatore,1363).
heuristic(bhubaneshwar,coimbatore,1400).
heuristic(bombay,coimbatore,999).
heuristic(calcutta,coimbatore,1766).
heuristic(calicut,coimbatore,132).
heuristic(chandigarh,coimbatore,2194).
heuristic(cochin,coimbatore,141).
heuristic(coimbatore,coimbatore,0).
heuristic(delhi,coimbatore,1962).
heuristic(gwalior,coimbatore,1695).
heuristic(hubli,coimbatore,522).
heuristic(hyderabad,coimbatore,725).
heuristic(imphal,coimbatore,2357).
heuristic(indore,coimbatore,1308).
heuristic(jabalpur,coimbatore,1388).
heuristic(jaipur,coimbatore,1773).
heuristic(jamshedpur,coimbatore,1638).
heuristic(jullundur,coimbatore,2274).
heuristic(kanpur,coimbatore,1754).
heuristic(kolhapur,coimbatore,698).
heuristic(lucknow,coimbatore,1809).
heuristic(ludhiana,coimbatore,2216).
heuristic(madras,coimbatore,427).
heuristic(madurai,coimbatore,173).
heuristic(meerut,coimbatore,2003).
heuristic(nagpur,coimbatore,1150).
heuristic(nasik,coimbatore,1057).
heuristic(panjim,coimbatore,604).
heuristic(patna,coimbatore,1837).
heuristic(pondicherry,coimbatore,329).
heuristic(pune,coimbatore,900).
heuristic(ranchi,coimbatore,1635).
heuristic(shillong,coimbatore,2255).
heuristic(shimla,coimbatore,2235).
heuristic(surat,coimbatore,7874).
heuristic(trivandrum,coimbatore,279).
heuristic(varanasi,coimbatore,1716).
heuristic(vijayawada,coimbatore,728).
heuristic(vishakapatnam,coimbatore,1011).
heuristic(agartala,delhi,1499).
heuristic(agra,delhi,181).
heuristic(ahmedabad,delhi,779).
heuristic(allahabad,delhi,579).
heuristic(amritsar,delhi,401).
heuristic(asansol,delhi,1118).
heuristic(bangalore,delhi,1743).
heuristic(baroda,delhi,813).
heuristic(bhopal,delhi,599).
heuristic(bhubaneshwar,delhi,1276).
heuristic(bombay,delhi,1152).
heuristic(calcutta,delhi,1304).
heuristic(calicut,delhi,1941).
heuristic(chandigarh,delhi,235).
heuristic(cochin,delhi,2083).
heuristic(coimbatore,delhi,1962).
heuristic(delhi,delhi,0).
heuristic(gwalior,delhi,287).
heuristic(hubli,delhi,1494).
heuristic(hyderabad,delhi,1262).
heuristic(imphal,delhi,1712).
heuristic(indore,delhi,673).
heuristic(jabalpur,delhi,668).
heuristic(jaipur,delhi,237).
heuristic(jamshedpur,delhi,1109).
heuristic(jullundur,delhi,344).
heuristic(kanpur,delhi,390).
heuristic(kolhapur,delhi,1363).
heuristic(lucknow,delhi,417).
heuristic(ludhiana,delhi,283).
heuristic(madras,delhi,1759).
heuristic(madurai,delhi,2084).
heuristic(meerut,delhi,65).
heuristic(nagpur,delhi,854).
heuristic(nasik,delhi,1021).
heuristic(panjim,delhi,1503).
heuristic(patna,delhi,851).
heuristic(pondicherry,delhi,1878).
heuristic(pune,delhi,1177).
heuristic(ranchi,delhi,999).
heuristic(shillong,delhi,1489).
heuristic(shimla,delhi,272).
heuristic(surat,delhi,6574).
heuristic(trivandrum,delhi,2242).
heuristic(varanasi,delhi,681).
heuristic(vijayawada,delhi,1394).
heuristic(vishakapatnam,delhi,1363).
heuristic(agartala,gwalior,1347).
heuristic(agra,gwalior,109).
heuristic(ahmedabad,gwalior,665).
heuristic(allahabad,gwalior,377).
heuristic(amritsar,gwalior,683).
heuristic(asansol,gwalior,931).
heuristic(bangalore,gwalior,1471).
heuristic(baroda,gwalior,664).
heuristic(bhopal,gwalior,336).
heuristic(bhubaneshwar,gwalior,1025).
heuristic(bombay,gwalior,959).
heuristic(calcutta,gwalior,1109).
heuristic(calicut,gwalior,1681).
heuristic(chandigarh,gwalior,521).
heuristic(cochin,gwalior,1820).
heuristic(coimbatore,gwalior,1695).
heuristic(delhi,gwalior,287).
heuristic(gwalior,gwalior,0).
heuristic(hubli,gwalior,1246).
heuristic(hyderabad,gwalior,983).
heuristic(imphal,gwalior,1590).
heuristic(indore,gwalior,451).
heuristic(jabalpur,gwalior,383).
heuristic(jaipur,gwalior,245).
heuristic(jamshedpur,gwalior,897).
heuristic(jullundur,gwalior,630).
heuristic(kanpur,gwalior,217).
heuristic(kolhapur,gwalior,1131).
heuristic(lucknow,gwalior,285).
heuristic(ludhiana,gwalior,569).
heuristic(madras,gwalior,1475).
heuristic(madurai,gwalior,1809).
heuristic(meerut,gwalior,313).
heuristic(nagpur,gwalior,569).
heuristic(nasik,gwalior,820).
heuristic(panjim,gwalior,1272).
heuristic(patna,gwalior,699).
heuristic(pondicherry,gwalior,1596).
heuristic(pune,gwalior,961).
heuristic(ranchi,gwalior,789).
heuristic(shillong,gwalior,1374).
heuristic(shimla,gwalior,553).
heuristic(surat,gwalior,6819).
heuristic(trivandrum,gwalior,1974).
heuristic(varanasi,gwalior,495).
heuristic(vijayawada,gwalior,1107).
heuristic(vishakapatnam,gwalior,1081).
heuristic(agartala,hubli,1933).
heuristic(agra,hubli,1347).
heuristic(ahmedabad,hubli,894).
heuristic(allahabad,hubli,1320).
heuristic(amritsar,hubli,1810).
heuristic(asansol,hubli,1547).
heuristic(bangalore,hubli,373).
heuristic(baroda,hubli,798).
heuristic(bhopal,hubli,910).
heuristic(bhubaneshwar,hubli,1257).
heuristic(bombay,hubli,478).
heuristic(calcutta,hubli,1604).
heuristic(calicut,hubli,461).
heuristic(chandigarh,hubli,1718).
heuristic(cochin,hubli,615).
heuristic(coimbatore,hubli,522).
heuristic(delhi,hubli,1494).
heuristic(gwalior,hubli,1246).
heuristic(hubli,hubli,0).
heuristic(hyderabad,hubli,420).
heuristic(imphal,hubli,2222).
heuristic(indore,hubli,822).
heuristic(jabalpur,hubli,1004).
heuristic(jaipur,hubli,1287).
heuristic(jamshedpur,hubli,1426).
heuristic(jullundur,hubli,1786).
heuristic(kanpur,hubli,1347).
heuristic(kolhapur,hubli,178).
heuristic(lucknow,hubli,1411).
heuristic(ludhiana,hubli,1731).
heuristic(madras,hubli,607).
heuristic(madurai,hubli,684).
heuristic(meerut,hubli,1541).
heuristic(nagpur,hubli,767).
heuristic(nasik,hubli,537).
heuristic(panjim,hubli,141).
heuristic(patna,hubli,1542).
heuristic(pondicherry,hubli,633).
heuristic(pune,hubli,377).
heuristic(ranchi,hubli,1390).
heuristic(shillong,hubli,2078).
heuristic(shimla,hubli,1763).
heuristic(surat,hubli,7394).
heuristic(trivandrum,hubli,788).
heuristic(varanasi,hubli,1379).
heuristic(vijayawada,hubli,599).
heuristic(vishakapatnam,hubli,907).
heuristic(agartala,hyderabad,1513).
heuristic(agra,hyderabad,1092).
heuristic(ahmedabad,hyderabad,879).
heuristic(allahabad,hyderabad,963).
heuristic(amritsar,hyderabad,1628).
heuristic(asansol,hyderabad,1130).
heuristic(bangalore,hyderabad,496).
heuristic(baroda,hyderabad,778).
heuristic(bhopal,hyderabad,665).
heuristic(bhubaneshwar,hyderabad,839).
heuristic(bombay,hyderabad,621).
heuristic(calcutta,hyderabad,1184).
heuristic(calicut,hyderabad,739).
heuristic(chandigarh,hyderabad,1496).
heuristic(cochin,hyderabad,859).
heuristic(coimbatore,hyderabad,725).
heuristic(delhi,hyderabad,1262).
heuristic(gwalior,hyderabad,983).
heuristic(hubli,hyderabad,420).
heuristic(hyderabad,hyderabad,0).
heuristic(imphal,hyderabad,1802).
heuristic(indore,hyderabad,655).
heuristic(jabalpur,hyderabad,663).
heuristic(jaipur,hyderabad,1096).
heuristic(jamshedpur,hyderabad,1008).
heuristic(jullundur,hyderabad,1589).
heuristic(kanpur,hyderabad,1029).
heuristic(kolhapur,hyderabad,455).
heuristic(lucknow,hyderabad,1083).
heuristic(ludhiana,hyderabad,1529).
heuristic(madras,hyderabad,513).
heuristic(madurai,hyderabad,827).
heuristic(meerut,hyderabad,1296).
heuristic(nagpur,hyderabad,426).
heuristic(nasik,hyderabad,574).
heuristic(panjim,hyderabad,536).
heuristic(patna,hyderabad,1146).
heuristic(pondicherry,hyderabad,620).
heuristic(pune,hyderabad,505).
heuristic(ranchi,hyderabad,977).
heuristic(shillong,hyderabad,1659).
heuristic(shimla,hyderabad,1533).
heuristic(surat,hyderabad,7498).
heuristic(trivandrum,hyderabad,1000).
heuristic(varanasi,hyderabad,1003).
heuristic(vijayawada,hyderabad,246).
heuristic(vishakapatnam,hyderabad,512).
heuristic(agartala,imphal,289).
heuristic(agra,imphal,1612).
heuristic(ahmedabad,imphal,2177).
heuristic(allahabad,imphal,1220).
heuristic(amritsar,imphal,2012).
heuristic(asansol,imphal,716).
heuristic(bangalore,imphal,2160).
heuristic(baroda,imphal,2130).
heuristic(bhopal,imphal,1686).
heuristic(bhubaneshwar,imphal,972).
heuristic(bombay,imphal,2260).
heuristic(calcutta,imphal,619).
heuristic(calicut,imphal,2435).
heuristic(chandigarh,imphal,1809).
heuristic(cochin,imphal,2494).
heuristic(coimbatore,imphal,2357).
heuristic(delhi,imphal,1712).
heuristic(gwalior,imphal,1590).
heuristic(hubli,imphal,2222).
heuristic(hyderabad,imphal,1802).
heuristic(imphal,imphal,0).
heuristic(indore,imphal,1851).
heuristic(jabalpur,imphal,1431).
heuristic(jaipur,imphal,1826).
heuristic(jamshedpur,imphal,817).
heuristic(jullundur,imphal,1938).
heuristic(kanpur,imphal,1376).
heuristic(kolhapur,imphal,2233).
heuristic(lucknow,imphal,1320).
heuristic(ludhiana,imphal,1900).
heuristic(madras,imphal,1937).
heuristic(madurai,imphal,2352).
heuristic(meerut,imphal,1668).
heuristic(nagpur,imphal,1572).
heuristic(nasik,imphal,2135).
heuristic(panjim,imphal,2335).
heuristic(patna,imphal,891).
heuristic(pondicherry,imphal,2061).
heuristic(pune,imphal,2186).
heuristic(ranchi,imphal,888).
heuristic(shillong,imphal,223).
heuristic(shimla,imphal,1787).
heuristic(surat,imphal,8107).
heuristic(trivandrum,imphal,2556).
heuristic(varanasi,imphal,1102).
heuristic(vijayawada,imphal,1662).
heuristic(vishakapatnam,imphal,1354).
heuristic(agartala,indore,1578).
heuristic(agra,indore,540).
heuristic(ahmedabad,indore,338).
heuristic(allahabad,indore,676).
heuristic(amritsar,indore,996).
heuristic(asansol,indore,1139).
heuristic(bangalore,indore,1098).
heuristic(baroda,indore,278).
heuristic(bhopal,indore,168).
heuristic(bhubaneshwar,indore,1067).
heuristic(bombay,indore,510).
heuristic(calcutta,indore,1282).
heuristic(calicut,indore,1276).
heuristic(chandigarh,indore,895).
heuristic(cochin,indore,1422).
heuristic(coimbatore,indore,1308).
heuristic(delhi,indore,673).
heuristic(gwalior,indore,451).
heuristic(hubli,indore,822).
heuristic(hyderabad,indore,655).
heuristic(imphal,indore,1851).
heuristic(indore,indore,0).
heuristic(jabalpur,indore,420).
heuristic(jaipur,indore,466).
heuristic(jamshedpur,indore,1059).
heuristic(jullundur,indore,967).
heuristic(kanpur,indore,612).
heuristic(kolhapur,indore,690).
heuristic(lucknow,indore,686).
heuristic(ludhiana,indore,910).
heuristic(madras,indore,1168).
heuristic(madurai,indore,1442).
heuristic(meerut,indore,723).
heuristic(nagpur,indore,374).
heuristic(nasik,indore,370).
heuristic(panjim,indore,831).
heuristic(patna,indore,992).
heuristic(pondicherry,indore,1270).
heuristic(pune,indore,511).
heuristic(ranchi,indore,970).
heuristic(shillong,indore,1654).
heuristic(shimla,indore,941).
heuristic(surat,indore,6895).
heuristic(trivandrum,indore,1586).
heuristic(varanasi,indore,781).
heuristic(vijayawada,indore,851).
heuristic(vishakapatnam,indore,952).
heuristic(agartala,jabalpur,1157).
heuristic(agra,jabalpur,487).
heuristic(ahmedabad,jabalpur,753).
heuristic(allahabad,jabalpur,317).
heuristic(amritsar,jabalpur,1066).
heuristic(asansol,jabalpur,719).
heuristic(bangalore,jabalpur,1159).
heuristic(baroda,jabalpur,699).
heuristic(bhopal,jabalpur,260).
heuristic(bhubaneshwar,jabalpur,688).
heuristic(bombay,jabalpur,862).
heuristic(calcutta,jabalpur,864).
heuristic(calicut,jabalpur,1396).
heuristic(chandigarh,jabalpur,898).
heuristic(cochin,jabalpur,1522).
heuristic(coimbatore,jabalpur,1388).
heuristic(delhi,jabalpur,668).
heuristic(gwalior,jabalpur,383).
heuristic(hubli,jabalpur,1004).
heuristic(hyderabad,jabalpur,663).
heuristic(imphal,jabalpur,1431).
heuristic(indore,jabalpur,420).
heuristic(jabalpur,jabalpur,0).
heuristic(jaipur,jabalpur,589).
heuristic(jamshedpur,jabalpur,641).
heuristic(jullundur,jabalpur,1012).
heuristic(kanpur,jabalpur,368).
heuristic(kolhapur,jabalpur,933).
heuristic(lucknow,jabalpur,420).
heuristic(ludhiana,jabalpur,952).
heuristic(madras,jabalpur,1121).
heuristic(madurai,jabalpur,1484).
heuristic(meerut,jabalpur,684).
heuristic(nagpur,jabalpur,240).
heuristic(nasik,jabalpur,726).
heuristic(panjim,jabalpur,1066).
heuristic(patna,jabalpur,590).
heuristic(pondicherry,jabalpur,1248).
heuristic(pune,jabalpur,816).
heuristic(ranchi,jabalpur,549).
heuristic(shillong,jabalpur,1237).
heuristic(shimla,jabalpur,924).
heuristic(surat,jabalpur,7177).
heuristic(trivandrum,jabalpur,1662).
heuristic(varanasi,jabalpur,393).
heuristic(vijayawada,jabalpur,742).
heuristic(vishakapatnam,jabalpur,697).
heuristic(agartala,jaipur,1589).
heuristic(agra,jaipur,218).
heuristic(ahmedabad,jaipur,542).
heuristic(allahabad,jaipur,622).
heuristic(amritsar,jaipur,532).
heuristic(asansol,jaipur,1176).
heuristic(bangalore,jaipur,1560).
heuristic(baroda,jaipur,577).
heuristic(bhopal,jaipur,436).
heuristic(bhubaneshwar,jaipur,1260).
heuristic(bombay,jaipur,921).
heuristic(calcutta,jaipur,1354).
heuristic(calicut,jaipur,1742).
heuristic(chandigarh,jaipur,434).
heuristic(cochin,jaipur,1889).
heuristic(coimbatore,jaipur,1773).
heuristic(delhi,jaipur,237).
heuristic(gwalior,jaipur,245).
heuristic(hubli,jaipur,1287).
heuristic(hyderabad,jaipur,1096).
heuristic(imphal,jaipur,1826).
heuristic(indore,jaipur,466).
heuristic(jabalpur,jaipur,589).
heuristic(jaipur,jaipur,0).
heuristic(jamshedpur,jaipur,1142).
heuristic(jullundur,jaipur,500).
heuristic(kanpur,jaipur,450).
heuristic(kolhapur,jaipur,1147).
heuristic(lucknow,jaipur,507).
heuristic(ludhiana,jaipur,444).
heuristic(madras,jaipur,1606).
heuristic(madurai,jaipur,1904).
heuristic(meerut,jaipur,300).
heuristic(nagpur,jaipur,721).
heuristic(nasik,jaipur,795).
heuristic(panjim,jaipur,1286).
heuristic(patna,jaipur,938).
heuristic(pondicherry,jaipur,1717).
heuristic(pune,jaipur,954).
heuristic(ranchi,jaipur,1034).
heuristic(shillong,jaipur,1607).
heuristic(shimla,jaipur,483).
heuristic(surat,jaipur,6589).
heuristic(trivandrum,jaipur,2052).
heuristic(varanasi,jaipur,738).
heuristic(vijayawada,jaipur,1258).
heuristic(vishakapatnam,jaipur,1278).
heuristic(agartala,jamshedpur,531).
heuristic(agra,jamshedpur,957).
heuristic(ahmedabad,jamshedpur,1395).
heuristic(allahabad,jamshedpur,531).
heuristic(amritsar,jamshedpur,1488).
heuristic(asansol,jamshedpur,126).
heuristic(bangalore,jamshedpur,1421).
heuristic(baroda,jamshedpur,1336).
heuristic(bhopal,jamshedpur,901).
heuristic(bhubaneshwar,jamshedpur,285).
heuristic(bombay,jamshedpur,1443).
heuristic(calcutta,jamshedpur,223).
heuristic(calicut,jamshedpur,1695).
heuristic(chandigarh,jamshedpur,1284).
heuristic(cochin,jamshedpur,1779).
heuristic(coimbatore,jamshedpur,1638).
heuristic(delhi,jamshedpur,1109).
heuristic(gwalior,jamshedpur,897).
heuristic(hubli,jamshedpur,1426).
heuristic(hyderabad,jamshedpur,1008).
heuristic(imphal,jamshedpur,817).
heuristic(indore,jamshedpur,1059).
heuristic(jabalpur,jamshedpur,641).
heuristic(jaipur,jamshedpur,1142).
heuristic(jamshedpur,jamshedpur,0).
heuristic(jullundur,jamshedpur,1418).
heuristic(kanpur,jamshedpur,720).
heuristic(kolhapur,jamshedpur,1422).
heuristic(lucknow,jamshedpur,695).
heuristic(ludhiana,jamshedpur,1365).
heuristic(madras,jamshedpur,1249).
heuristic(madurai,jamshedpur,1670).
heuristic(meerut,jamshedpur,1088).
heuristic(nagpur,jamshedpur,756).
heuristic(nasik,jamshedpur,1321).
heuristic(panjim,jamshedpur,1531).
heuristic(patna,jamshedpur,330).
heuristic(pondicherry,jamshedpur,1384).
heuristic(pune,jamshedpur,1369).
heuristic(ranchi,jamshedpur,109).
heuristic(shillong,jamshedpur,653).
heuristic(shimla,jamshedpur,1284).
heuristic(surat,jamshedpur,7680).
heuristic(trivandrum,jamshedpur,1873).
heuristic(varanasi,jamshedpur,429).
heuristic(vijayawada,jamshedpur,911).
heuristic(vishakapatnam,jamshedpur,641).
heuristic(agartala,jullundur,1756).
heuristic(agra,jullundur,525).
heuristic(ahmedabad,jullundur,980).
heuristic(allahabad,jullundur,900).
heuristic(amritsar,jullundur,74).
heuristic(asansol,jullundur,1410).
heuristic(bangalore,jullundur,2060).
heuristic(baroda,jullundur,1042).
heuristic(bhopal,jullundur,924).
heuristic(bhubaneshwar,jullundur,1606).
heuristic(bombay,jullundur,1399).
heuristic(calcutta,jullundur,1598).
heuristic(calicut,jullundur,2243).
heuristic(chandigarh,jullundur,134).
heuristic(cochin,jullundur,2390).
heuristic(coimbatore,jullundur,2274).
heuristic(delhi,jullundur,344).
heuristic(gwalior,jullundur,630).
heuristic(hubli,jullundur,1786).
heuristic(hyderabad,jullundur,1589).
heuristic(imphal,jullundur,1938).
heuristic(indore,jullundur,967).
heuristic(jabalpur,jullundur,1012).
heuristic(jaipur,jullundur,500).
heuristic(jamshedpur,jullundur,1418).
heuristic(jullundur,jullundur,0).
heuristic(kanpur,jullundur,716).
heuristic(kolhapur,jullundur,1642).
heuristic(lucknow,jullundur,725).
heuristic(ludhiana,jullundur,60).
heuristic(madras,jullundur,2093).
heuristic(madurai,jullundur,2403).
heuristic(meerut,jullundur,338).
heuristic(nagpur,jullundur,1192).
heuristic(nasik,jullundur,1281).
heuristic(panjim,jullundur,1779).
heuristic(patna,jullundur,1130).
heuristic(pondicherry,jullundur,2209).
heuristic(pune,jullundur,1444).
heuristic(ranchi,jullundur,1309).
heuristic(shillong,jullundur,1714).
heuristic(shimla,jullundur,151).
heuristic(surat,jullundur,6263).
heuristic(trivandrum,jullundur,2553).
heuristic(varanasi,jullundur,989).
heuristic(vijayawada,jullundur,1733).
heuristic(vishakapatnam,jullundur,1707).
heuristic(agartala,kanpur,1140).
heuristic(agra,kanpur,242).
heuristic(ahmedabad,kanpur,870).
heuristic(allahabad,kanpur,189).
heuristic(amritsar,kanpur,781).
heuristic(asansol,kanpur,737).
heuristic(bangalore,kanpur,1526).
heuristic(baroda,kanpur,857).
heuristic(bhopal,kanpur,462).
heuristic(bhubaneshwar,kanpur,890).
heuristic(bombay,kanpur,1120).
heuristic(calcutta,kanpur,921).
heuristic(calicut,kanpur,1757).
heuristic(chandigarh,kanpur,587).
heuristic(cochin,kanpur,1886).
heuristic(coimbatore,kanpur,1754).
heuristic(delhi,kanpur,390).
heuristic(gwalior,kanpur,217).
heuristic(hubli,kanpur,1347).
heuristic(hyderabad,kanpur,1029).
heuristic(imphal,kanpur,1376).
heuristic(indore,kanpur,612).
heuristic(jabalpur,kanpur,368).
heuristic(jaipur,kanpur,450).
heuristic(jamshedpur,kanpur,720).
heuristic(jullundur,kanpur,716).
heuristic(kanpur,kanpur,0).
heuristic(kolhapur,kanpur,1253).
heuristic(lucknow,kanpur,73).
heuristic(ludhiana,kanpur,659).
heuristic(madras,kanpur,1487).
heuristic(madurai,kanpur,1853).
heuristic(meerut,kanpur,378).
heuristic(nagpur,kanpur,603).
heuristic(nasik,kanpur,979).
heuristic(panjim,kanpur,1392).
heuristic(patna,kanpur,488).
heuristic(pondicherry,kanpur,1616).
heuristic(pune,kanpur,1104).
heuristic(ranchi,kanpur,610).
heuristic(shillong,kanpur,1159).
heuristic(shimla,kanpur,600).
heuristic(surat,kanpur,6965).
heuristic(trivandrum,kanpur,2029).
heuristic(varanasi,kanpur,296).
heuristic(vijayawada,kanpur,1107).
heuristic(vishakapatnam,kanpur,1018).
heuristic(agartala,kolhapur,1944).
heuristic(agra,kolhapur,1227).
heuristic(ahmedabad,kolhapur,723).
heuristic(allahabad,kolhapur,1249).
heuristic(amritsar,kolhapur,1661).
heuristic(asansol,kolhapur,1537).
heuristic(bangalore,kolhapur,548).
heuristic(baroda,kolhapur,631).
heuristic(bhopal,kolhapur,800).
heuristic(bhubaneshwar,kolhapur,1285).
heuristic(bombay,kolhapur,300).
heuristic(calcutta,kolhapur,1615).
heuristic(calicut,kolhapur,629).
heuristic(chandigarh,kolhapur,1581).
heuristic(cochin,kolhapur,784).
heuristic(coimbatore,kolhapur,698).
heuristic(delhi,kolhapur,1363).
heuristic(gwalior,kolhapur,1131).
heuristic(hubli,kolhapur,178).
heuristic(hyderabad,kolhapur,455).
heuristic(imphal,kolhapur,2233).
heuristic(indore,kolhapur,690).
heuristic(jabalpur,kolhapur,933).
heuristic(jaipur,kolhapur,1147).
heuristic(jamshedpur,kolhapur,1422).
heuristic(jullundur,kolhapur,1642).
heuristic(kanpur,kolhapur,1253).
heuristic(kolhapur,kolhapur,0).
heuristic(lucknow,kolhapur,1321).
heuristic(ludhiana,kolhapur,1588).
heuristic(madras,kolhapur,762).
heuristic(madurai,kolhapur,862).
heuristic(meerut,kolhapur,1414).
heuristic(nagpur,kolhapur,709).
heuristic(nasik,kolhapur,370).
heuristic(panjim,kolhapur,140).
heuristic(patna,kolhapur,1500).
heuristic(pondicherry,kolhapur,802).
heuristic(pune,kolhapur,206).
heuristic(ranchi,kolhapur,1373).
heuristic(shillong,kolhapur,2075).
heuristic(shimla,kolhapur,1628).
heuristic(surat,kolhapur,7221).
heuristic(trivandrum,kolhapur,959).
heuristic(varanasi,kolhapur,1321).
heuristic(vijayawada,kolhapur,679).
heuristic(vishakapatnam,kolhapur,967).
heuristic(agartala,lucknow,1091).
heuristic(agra,lucknow,292).
heuristic(ahmedabad,lucknow,942).
heuristic(allahabad,lucknow,179).
heuristic(amritsar,lucknow,793).
heuristic(asansol,lucknow,701).
heuristic(bangalore,lucknow,1580).
heuristic(baroda,lucknow,931).
heuristic(bhopal,lucknow,533).
heuristic(bhubaneshwar,lucknow,885).
heuristic(bombay,lucknow,1192).
heuristic(calcutta,lucknow,887).
heuristic(calicut,lucknow,1816).
heuristic(chandigarh,lucknow,592).
heuristic(cochin,lucknow,1942).
heuristic(coimbatore,lucknow,1809).
heuristic(delhi,lucknow,417).
heuristic(gwalior,lucknow,285).
heuristic(hubli,lucknow,1411).
heuristic(hyderabad,lucknow,1083).
heuristic(imphal,lucknow,1320).
heuristic(indore,lucknow,686).
heuristic(jabalpur,lucknow,420).
heuristic(jaipur,lucknow,507).
heuristic(jamshedpur,lucknow,695).
heuristic(jullundur,lucknow,725).
heuristic(kanpur,lucknow,73).
heuristic(kolhapur,lucknow,1321).
heuristic(lucknow,lucknow,0).
heuristic(ludhiana,lucknow,670).
heuristic(madras,lucknow,1530).
heuristic(madurai,lucknow,1903).
heuristic(meerut,lucknow,393).
heuristic(nagpur,lucknow,659).
heuristic(nasik,lucknow,1051).
heuristic(panjim,lucknow,1459).
heuristic(patna,lucknow,439).
heuristic(pondicherry,lucknow,1661).
heuristic(pune,lucknow,1175).
heuristic(ranchi,lucknow,586).
heuristic(shillong,lucknow,1100).
heuristic(shimla,lucknow,599).
heuristic(surat,lucknow,6984).
heuristic(trivandrum,lucknow,2083).
heuristic(varanasi,lucknow,266).
heuristic(vijayawada,lucknow,1149).
heuristic(vishakapatnam,lucknow,1042).
heuristic(agartala,ludhiana,1712).
heuristic(agra,ludhiana,465).
heuristic(ahmedabad,ludhiana,934).
heuristic(allahabad,ludhiana,844).
heuristic(amritsar,ludhiana,123).
heuristic(asansol,ludhiana,1359).
heuristic(bangalore,ludhiana,2001).
heuristic(baroda,ludhiana,993).
heuristic(bhopal,ludhiana,864).
heuristic(bhubaneshwar,ludhiana,1549).
heuristic(bombay,ludhiana,1348).
heuristic(calcutta,ludhiana,1548).
heuristic(calicut,ludhiana,2186).
heuristic(chandigarh,ludhiana,90).
heuristic(cochin,ludhiana,2333).
heuristic(coimbatore,ludhiana,2216).
heuristic(delhi,ludhiana,283).
heuristic(gwalior,ludhiana,569).
heuristic(hubli,ludhiana,1731).
heuristic(hyderabad,ludhiana,1529).
heuristic(imphal,ludhiana,1900).
heuristic(indore,ludhiana,910).
heuristic(jabalpur,ludhiana,952).
heuristic(jaipur,ludhiana,444).
heuristic(jamshedpur,ludhiana,1365).
heuristic(jullundur,ludhiana,60).
heuristic(kanpur,ludhiana,659).
heuristic(kolhapur,ludhiana,1588).
heuristic(lucknow,ludhiana,670).
heuristic(ludhiana,ludhiana,0).
heuristic(madras,ludhiana,2033).
heuristic(madurai,ludhiana,2344).
heuristic(meerut,ludhiana,281).
heuristic(nagpur,ludhiana,1131).
heuristic(nasik,ludhiana,1229).
heuristic(panjim,ludhiana,1725).
heuristic(patna,ludhiana,1081).
heuristic(pondicherry,ludhiana,2149).
heuristic(pune,ludhiana,1392).
heuristic(ranchi,ludhiana,1256).
heuristic(shillong,ludhiana,1676).
heuristic(shimla,ludhiana,127).
heuristic(surat,ludhiana,6315).
heuristic(trivandrum,ludhiana,2495).
heuristic(varanasi,ludhiana,935).
heuristic(vijayawada,ludhiana,1672).
heuristic(vishakapatnam,ludhiana,1647).
heuristic(agartala,madras,1664).
heuristic(agra,madras,1584).
heuristic(ahmedabad,madras,1371).
heuristic(allahabad,madras,1383).
heuristic(amritsar,madras,2135).
heuristic(asansol,madras,1374).
heuristic(bangalore,madras,290).
heuristic(baroda,madras,1268).
heuristic(bhopal,madras,1171).
heuristic(bhubaneshwar,madras,994).
heuristic(bombay,madras,1033).
heuristic(calcutta,madras,1358).
heuristic(calicut,madras,529).
heuristic(chandigarh,madras,1994).
heuristic(cochin,madras,559).
heuristic(coimbatore,madras,427).
heuristic(delhi,madras,1759).
heuristic(gwalior,madras,1475).
heuristic(hubli,madras,607).
heuristic(hyderabad,madras,513).
heuristic(imphal,madras,1937).
heuristic(indore,madras,1168).
heuristic(jabalpur,madras,1121).
heuristic(jaipur,madras,1606).
heuristic(jamshedpur,madras,1249).
heuristic(jullundur,madras,2093).
heuristic(kanpur,madras,1487).
heuristic(kolhapur,madras,762).
heuristic(lucknow,madras,1530).
heuristic(ludhiana,madras,2033).
heuristic(madras,madras,0).
heuristic(madurai,madras,422).
heuristic(meerut,madras,1788).
heuristic(nagpur,madras,905).
heuristic(nasik,madras,1034).
heuristic(panjim,madras,744).
heuristic(patna,madras,1482).
heuristic(pondicherry,madras,136).
heuristic(pune,madras,914).
heuristic(ranchi,madras,1261).
heuristic(shillong,madras,1845).
heuristic(shimla,madras,2028).
heuristic(surat,madras,7966).
heuristic(trivandrum,madras,626).
heuristic(varanasi,madras,1392).
heuristic(vijayawada,madras,382).
heuristic(vishakapatnam,madras,608).
heuristic(agartala,madurai,2083).
heuristic(agra,madurai,1918).
heuristic(ahmedabad,madurai,1570).
heuristic(allahabad,madurai,1768).
heuristic(amritsar,madurai,2436).
heuristic(asansol,madurai,1795).
heuristic(bangalore,madurai,343).
heuristic(baroda,madurai,1472).
heuristic(bhopal,madurai,1484).
heuristic(bhubaneshwar,madurai,1416).
heuristic(bombay,madurai,1163).
heuristic(calcutta,madurai,1779).
heuristic(calicut,madurai,294).
heuristic(chandigarh,madurai,2317).
heuristic(cochin,madurai,202).
heuristic(coimbatore,madurai,173).
heuristic(delhi,madurai,2084).
heuristic(gwalior,madurai,1809).
heuristic(hubli,madurai,684).
heuristic(hyderabad,madurai,827).
heuristic(imphal,madurai,2352).
heuristic(indore,madurai,1442).
heuristic(jabalpur,madurai,1484).
heuristic(jaipur,madurai,1904).
heuristic(jamshedpur,madurai,1670).
heuristic(jullundur,madurai,2403).
heuristic(kanpur,madurai,1853).
heuristic(kolhapur,madurai,862).
heuristic(lucknow,madurai,1903).
heuristic(ludhiana,madurai,2344).
heuristic(madras,madurai,422).
heuristic(madurai,madurai,0).
heuristic(meerut,madurai,2121).
heuristic(nagpur,madurai,1252).
heuristic(nasik,madurai,1213).
heuristic(panjim,madurai,774).
heuristic(patna,madurai,1894).
heuristic(pondicherry,madurai,291).
heuristic(pune,madurai,1060).
heuristic(ranchi,madurai,1679).
heuristic(shillong,madurai,2266).
heuristic(shimla,madurai,2356).
heuristic(surat,madurai,8047).
heuristic(trivandrum,madurai,204).
heuristic(varanasi,madurai,1789).
heuristic(vijayawada,madurai,780).
heuristic(vishakapatnam,madurai,1031).
heuristic(agartala,meerut,1462).
heuristic(agra,meerut,204).
heuristic(ahmedabad,meerut,842).
heuristic(allahabad,meerut,564).
heuristic(amritsar,meerut,403).
heuristic(asansol,meerut,1090).
heuristic(bangalore,meerut,1781).
heuristic(baroda,meerut,874).
heuristic(bhopal,meerut,639).
heuristic(bhubaneshwar,meerut,1268).
heuristic(bombay,meerut,1209).
heuristic(calcutta,meerut,1278).
heuristic(calicut,meerut,1985).
heuristic(chandigarh,meerut,214).
heuristic(cochin,meerut,2126).
heuristic(coimbatore,meerut,2003).
heuristic(delhi,meerut,65).
heuristic(gwalior,meerut,313).
heuristic(hubli,meerut,1541).
heuristic(hyderabad,meerut,1296).
heuristic(imphal,meerut,1668).
heuristic(indore,meerut,723).
heuristic(jabalpur,meerut,684).
heuristic(jaipur,meerut,300).
heuristic(jamshedpur,meerut,1088).
heuristic(jullundur,meerut,338).
heuristic(kanpur,meerut,378).
heuristic(kolhapur,meerut,1414).
heuristic(lucknow,meerut,393).
heuristic(ludhiana,meerut,281).
heuristic(madras,meerut,1788).
heuristic(madurai,meerut,2121).
heuristic(meerut,meerut,0).
heuristic(nagpur,meerut,882).
heuristic(nasik,meerut,1077).
heuristic(panjim,meerut,1554).
heuristic(patna,meerut,818).
heuristic(pondicherry,meerut,1909).
heuristic(pune,meerut,1231).
heuristic(ranchi,meerut,979).
heuristic(shillong,meerut,1444).
heuristic(shimla,meerut,240).
heuristic(surat,meerut,6591).
heuristic(trivandrum,meerut,2282).
heuristic(varanasi,meerut,659).
heuristic(vijayawada,meerut,1419).
heuristic(vishakapatnam,meerut,1374).
heuristic(agartala,nagpur,1287).
heuristic(agra,nagpur,678).
heuristic(ahmedabad,nagpur,701).
heuristic(allahabad,nagpur,553).
heuristic(amritsar,nagpur,1238).
heuristic(asansol,nagpur,858).
heuristic(bangalore,nagpur,922).
heuristic(baroda,nagpur,621).
heuristic(bhopal,nagpur,291).
heuristic(bhubaneshwar,nagpur,709).
heuristic(bombay,nagpur,687).
heuristic(calcutta,nagpur,970).
heuristic(calicut,nagpur,1156).
heuristic(chandigarh,nagpur,1090).
heuristic(cochin,nagpur,1283).
heuristic(coimbatore,nagpur,1150).
heuristic(delhi,nagpur,854).
heuristic(gwalior,nagpur,569).
heuristic(hubli,nagpur,767).
heuristic(hyderabad,nagpur,426).
heuristic(imphal,nagpur,1572).
heuristic(indore,nagpur,374).
heuristic(jabalpur,nagpur,240).
heuristic(jaipur,nagpur,721).
heuristic(jamshedpur,nagpur,756).
heuristic(jullundur,nagpur,1192).
heuristic(kanpur,nagpur,603).
heuristic(kolhapur,nagpur,709).
heuristic(lucknow,nagpur,659).
heuristic(ludhiana,nagpur,1131).
heuristic(madras,nagpur,905).
heuristic(madurai,nagpur,1252).
heuristic(meerut,nagpur,882).
heuristic(nagpur,nagpur,0).
heuristic(nasik,nagpur,565).
heuristic(panjim,nagpur,837).
heuristic(patna,nagpur,791).
heuristic(pondicherry,nagpur,1027).
heuristic(pune,nagpur,619).
heuristic(ranchi,nagpur,688).
heuristic(shillong,nagpur,1395).
heuristic(shimla,nagpur,1123).
heuristic(surat,nagpur,7259).
heuristic(trivandrum,nagpur,1426).
heuristic(varanasi,nagpur,614).
heuristic(vijayawada,nagpur,540).
heuristic(vishakapatnam,nagpur,583).
heuristic(agartala,nasik,1852).
heuristic(agra,nasik,905).
heuristic(ahmedabad,nasik,357).
heuristic(allahabad,nasik,1021).
heuristic(amritsar,nasik,1296).
heuristic(asansol,nasik,1420).
heuristic(bangalore,nasik,880).
heuristic(baroda,nasik,261).
heuristic(bhopal,nasik,519).
heuristic(bhubaneshwar,nasik,1257).
heuristic(bombay,nasik,141).
heuristic(calcutta,nasik,1535).
heuristic(calicut,nasik,997).
heuristic(chandigarh,nasik,1229).
heuristic(cochin,nasik,1151).
heuristic(coimbatore,nasik,1057).
heuristic(delhi,nasik,1021).
heuristic(gwalior,nasik,820).
heuristic(hubli,nasik,537).
heuristic(hyderabad,nasik,574).
heuristic(imphal,nasik,2135).
heuristic(indore,nasik,370).
heuristic(jabalpur,nasik,726).
heuristic(jaipur,nasik,795).
heuristic(jamshedpur,nasik,1321).
heuristic(jullundur,nasik,1281).
heuristic(kanpur,nasik,979).
heuristic(kolhapur,nasik,370).
heuristic(lucknow,nasik,1051).
heuristic(ludhiana,nasik,1229).
heuristic(madras,nasik,1034).
heuristic(madurai,nasik,1213).
heuristic(meerut,nasik,1077).
heuristic(nagpur,nasik,565).
heuristic(nasik,nasik,0).
heuristic(panjim,nasik,501).
heuristic(patna,nasik,1317).
heuristic(pondicherry,nasik,1105).
heuristic(pune,nasik,165).
heuristic(ranchi,nasik,1248).
heuristic(shillong,nasik,1952).
heuristic(shimla,nasik,1279).
heuristic(surat,nasik,6935).
heuristic(trivandrum,nasik,1325).
heuristic(varanasi,nasik,1115).
heuristic(vijayawada,nasik,819).
heuristic(vishakapatnam,nasik,1031).
heuristic(agartala,panjim,2046).
heuristic(agra,panjim,1368).
heuristic(ahmedabad,panjim,846).
heuristic(allahabad,panjim,1383).
heuristic(amritsar,panjim,1797).
heuristic(asansol,panjim,1649).
heuristic(bangalore,panjim,492).
heuristic(baroda,panjim,758).
heuristic(bhopal,panjim,940).
heuristic(bhubaneshwar,panjim,1376).
heuristic(bombay,panjim,410).
heuristic(calcutta,panjim,1716).
heuristic(calicut,panjim,517).
heuristic(chandigarh,panjim,1720).
heuristic(cochin,panjim,673).
heuristic(coimbatore,panjim,604).
heuristic(delhi,panjim,1503).
heuristic(gwalior,panjim,1272).
heuristic(hubli,panjim,141).
heuristic(hyderabad,panjim,536).
heuristic(imphal,panjim,2335).
heuristic(indore,panjim,831).
heuristic(jabalpur,panjim,1066).
heuristic(jaipur,panjim,1286).
heuristic(jamshedpur,panjim,1531).
heuristic(jullundur,panjim,1779).
heuristic(kanpur,panjim,1392).
heuristic(kolhapur,panjim,140).
heuristic(lucknow,panjim,1459).
heuristic(ludhiana,panjim,1725).
heuristic(madras,panjim,744).
heuristic(madurai,panjim,774).
heuristic(meerut,panjim,1554).
heuristic(nagpur,panjim,837).
heuristic(nasik,panjim,501).
heuristic(panjim,panjim,0).
heuristic(patna,panjim,1625).
heuristic(pondicherry,panjim,759).
heuristic(pune,panjim,336).
heuristic(ranchi,panjim,1488).
heuristic(shillong,panjim,2184).
heuristic(shimla,panjim,1768).
heuristic(surat,panjim,7281).
heuristic(trivandrum,panjim,850).
heuristic(varanasi,panjim,1451).
heuristic(vijayawada,panjim,734).
heuristic(vishakapatnam,panjim,1037).
heuristic(agartala,patna,652).
heuristic(agra,patna,729).
heuristic(ahmedabad,patna,1302).
heuristic(allahabad,patna,330).
heuristic(amritsar,patna,1203).
heuristic(asansol,patna,284).
heuristic(bangalore,patna,1610).
heuristic(baroda,patna,1266).
heuristic(bhopal,patna,824).
heuristic(bhubaneshwar,patna,599).
heuristic(bombay,patna,1452).
heuristic(calcutta,patna,471).
heuristic(calicut,patna,1875).
heuristic(chandigarh,patna,996).
heuristic(cochin,patna,1977).
heuristic(coimbatore,patna,1837).
heuristic(delhi,patna,851).
heuristic(gwalior,patna,699).
heuristic(hubli,patna,1542).
heuristic(hyderabad,patna,1146).
heuristic(imphal,patna,891).
heuristic(indore,patna,992).
heuristic(jabalpur,patna,590).
heuristic(jaipur,patna,938).
heuristic(jamshedpur,patna,330).
heuristic(jullundur,patna,1130).
heuristic(kanpur,patna,488).
heuristic(kolhapur,patna,1500).
heuristic(lucknow,patna,439).
heuristic(ludhiana,patna,1081).
heuristic(madras,patna,1482).
heuristic(madurai,patna,1894).
heuristic(meerut,patna,818).
heuristic(nagpur,patna,791).
heuristic(nasik,patna,1317).
heuristic(panjim,patna,1625).
heuristic(patna,patna,0).
heuristic(pondicherry,patna,1618).
heuristic(pune,patna,1402).
heuristic(ranchi,patna,249).
heuristic(shillong,patna,677).
heuristic(shimla,patna,988).
heuristic(surat,patna,7390).
heuristic(trivandrum,patna,2091).
heuristic(varanasi,patna,214).
heuristic(vijayawada,patna,1114).
heuristic(vishakapatnam,patna,897).
heuristic(agartala,pondicherry,1792).
heuristic(agra,pondicherry,1705).
heuristic(ahmedabad,pondicherry,1452).
heuristic(allahabad,pondicherry,1516).
heuristic(amritsar,pondicherry,2248).
heuristic(asansol,pondicherry,1509).
heuristic(bangalore,pondicherry,269).
heuristic(baroda,pondicherry,1350).
heuristic(bhopal,pondicherry,1285).
heuristic(bhubaneshwar,pondicherry,1126).
heuristic(bombay,pondicherry,1088).
heuristic(calcutta,pondicherry,1489).
heuristic(calicut,pondicherry,448).
heuristic(chandigarh,pondicherry,2113).
heuristic(cochin,pondicherry,448).
heuristic(coimbatore,pondicherry,329).
heuristic(delhi,pondicherry,1878).
heuristic(gwalior,pondicherry,1596).
heuristic(hubli,pondicherry,633).
heuristic(hyderabad,pondicherry,620).
heuristic(imphal,pondicherry,2061).
heuristic(indore,pondicherry,1270).
heuristic(jabalpur,pondicherry,1248).
heuristic(jaipur,pondicherry,1717).
heuristic(jamshedpur,pondicherry,1384).
heuristic(jullundur,pondicherry,2209).
heuristic(kanpur,pondicherry,1616).
heuristic(kolhapur,pondicherry,802).
heuristic(lucknow,pondicherry,1661).
heuristic(ludhiana,pondicherry,2149).
heuristic(madras,pondicherry,136).
heuristic(madurai,pondicherry,291).
heuristic(meerut,pondicherry,1909).
heuristic(nagpur,pondicherry,1027).
heuristic(nasik,pondicherry,1105).
heuristic(panjim,pondicherry,759).
heuristic(patna,pondicherry,1618).
heuristic(pondicherry,pondicherry,0).
heuristic(pune,pondicherry,973).
heuristic(ranchi,pondicherry,1398).
heuristic(shillong,pondicherry,1974).
heuristic(shimla,pondicherry,2149).
heuristic(surat,pondicherry,8022).
heuristic(trivandrum,pondicherry,496).
heuristic(varanasi,pondicherry,1527).
heuristic(vijayawada,pondicherry,515).
heuristic(vishakapatnam,pondicherry,743).
heuristic(agartala,pune,1899).
heuristic(agra,pune,1052).
heuristic(ahmedabad,pune,517).
heuristic(allahabad,pune,1125).
heuristic(amritsar,pune,1461).
heuristic(asansol,pune,1476).
heuristic(bangalore,pune,734).
heuristic(baroda,pune,425).
heuristic(bhopal,pune,642).
heuristic(bhubaneshwar,pune,1271).
heuristic(bombay,pune,119).
heuristic(calcutta,pune,1575).
heuristic(calicut,pune,834).
heuristic(chandigarh,pune,1389).
heuristic(cochin,pune,989).
heuristic(coimbatore,pune,900).
heuristic(delhi,pune,1177).
heuristic(gwalior,pune,961).
heuristic(hubli,pune,377).
heuristic(hyderabad,pune,505).
heuristic(imphal,pune,2186).
heuristic(indore,pune,511).
heuristic(jabalpur,pune,816).
heuristic(jaipur,pune,954).
heuristic(jamshedpur,pune,1369).
heuristic(jullundur,pune,1444).
heuristic(kanpur,pune,1104).
heuristic(kolhapur,pune,206).
heuristic(lucknow,pune,1175).
heuristic(ludhiana,pune,1392).
heuristic(madras,pune,914).
heuristic(madurai,pune,1060).
heuristic(meerut,pune,1231).
heuristic(nagpur,pune,619).
heuristic(nasik,pune,165).
heuristic(panjim,pune,336).
heuristic(patna,pune,1402).
heuristic(pondicherry,pune,973).
heuristic(pune,pune,0).
heuristic(ranchi,pune,1306).
heuristic(shillong,pune,2014).
heuristic(shimla,pune,1438).
heuristic(surat,pune,7052).
heuristic(trivandrum,pune,1164).
heuristic(varanasi,pune,1209).
heuristic(vijayawada,pune,751).
heuristic(vishakapatnam,pune,1000).
heuristic(agartala,ranchi,609).
heuristic(agra,ranchi,848).
heuristic(ahmedabad,ranchi,1302).
heuristic(allahabad,ranchi,421).
heuristic(amritsar,ranchi,1379).
heuristic(asansol,ranchi,171).
heuristic(bangalore,ranchi,1414).
heuristic(baroda,ranchi,1248).
heuristic(bhopal,ranchi,809).
heuristic(bhubaneshwar,ranchi,349).
heuristic(bombay,ranchi,1374).
heuristic(calcutta,ranchi,323).
heuristic(calicut,ranchi,1685).
heuristic(chandigarh,ranchi,1176).
heuristic(cochin,ranchi,1777).
heuristic(coimbatore,ranchi,1635).
heuristic(delhi,ranchi,999).
heuristic(gwalior,ranchi,789).
heuristic(hubli,ranchi,1390).
heuristic(hyderabad,ranchi,977).
heuristic(imphal,ranchi,888).
heuristic(indore,ranchi,970).
heuristic(jabalpur,ranchi,549).
heuristic(jaipur,ranchi,1034).
heuristic(jamshedpur,ranchi,109).
heuristic(jullundur,ranchi,1309).
heuristic(kanpur,ranchi,610).
heuristic(kolhapur,ranchi,1373).
heuristic(lucknow,ranchi,586).
heuristic(ludhiana,ranchi,1256).
heuristic(madras,ranchi,1261).
heuristic(madurai,ranchi,1679).
heuristic(meerut,ranchi,979).
heuristic(nagpur,ranchi,688).
heuristic(nasik,ranchi,1248).
heuristic(panjim,ranchi,1488).
heuristic(patna,ranchi,249).
heuristic(pondicherry,ranchi,1398).
heuristic(pune,ranchi,1306).
heuristic(ranchi,ranchi,0).
heuristic(shillong,ranchi,707).
heuristic(shimla,ranchi,1177).
heuristic(surat,ranchi,7571).
heuristic(trivandrum,ranchi,1880).
heuristic(varanasi,ranchi,320).
heuristic(vijayawada,ranchi,907).
heuristic(vishakapatnam,ranchi,662).
heuristic(agartala,shillong,203).
heuristic(agra,shillong,1392).
heuristic(ahmedabad,shillong,1974).
heuristic(allahabad,shillong,1008).
heuristic(amritsar,shillong,1789).
heuristic(asansol,shillong,538).
heuristic(bangalore,shillong,2049).
heuristic(baroda,shillong,1932).
heuristic(bhopal,shillong,1487).
heuristic(bhubaneshwar,shillong,855).
heuristic(bombay,shillong,2081).
heuristic(calcutta,shillong,488).
heuristic(calicut,shillong,2324).
heuristic(chandigarh,shillong,1586).
heuristic(cochin,shillong,2395).
heuristic(coimbatore,shillong,2255).
heuristic(delhi,shillong,1489).
heuristic(gwalior,shillong,1374).
heuristic(hubli,shillong,2078).
heuristic(hyderabad,shillong,1659).
heuristic(imphal,shillong,223).
heuristic(indore,shillong,1654).
heuristic(jabalpur,shillong,1237).
heuristic(jaipur,shillong,1607).
heuristic(jamshedpur,shillong,653).
heuristic(jullundur,shillong,1714).
heuristic(kanpur,shillong,1159).
heuristic(kolhapur,shillong,2075).
heuristic(lucknow,shillong,1100).
heuristic(ludhiana,shillong,1676).
heuristic(madras,shillong,1845).
heuristic(madurai,shillong,2266).
heuristic(meerut,shillong,1444).
heuristic(nagpur,shillong,1395).
heuristic(nasik,shillong,1952).
heuristic(panjim,shillong,2184).
heuristic(patna,shillong,677).
heuristic(pondicherry,shillong,1974).
heuristic(pune,shillong,2014).
heuristic(ranchi,shillong,707).
heuristic(shillong,shillong,0).
heuristic(shimla,shillong,1563).
heuristic(surat,shillong,7896).
heuristic(trivandrum,shillong,2471).
heuristic(varanasi,shillong,891).
heuristic(vijayawada,shillong,1542).
heuristic(vishakapatnam,shillong,1244).
heuristic(agartala,shimla,1607).
heuristic(agra,shimla,444).
heuristic(ahmedabad,shimla,1006).
heuristic(allahabad,shimla,777).
heuristic(amritsar,shimla,225).
heuristic(asansol,shimla,1270).
heuristic(bangalore,shimla,2016).
heuristic(baroda,shimla,1055).
heuristic(bhopal,shimla,872).
heuristic(bhubaneshwar,shimla,1484).
heuristic(bombay,shimla,1404).
heuristic(calcutta,shimla,1458).
heuristic(calicut,shimla,2212).
heuristic(chandigarh,shimla,55).
heuristic(cochin,shimla,2356).
heuristic(coimbatore,shimla,2235).
heuristic(delhi,shimla,272).
heuristic(gwalior,shimla,553).
heuristic(hubli,shimla,1763).
heuristic(hyderabad,shimla,1533).
heuristic(imphal,shimla,1787).
heuristic(indore,shimla,941).
heuristic(jabalpur,shimla,924).
heuristic(jaipur,shimla,483).
heuristic(jamshedpur,shimla,1284).
heuristic(jullundur,shimla,151).
heuristic(kanpur,shimla,600).
heuristic(kolhapur,shimla,1628).
heuristic(lucknow,shimla,599).
heuristic(ludhiana,shimla,127).
heuristic(madras,shimla,2028).
heuristic(madurai,shimla,2356).
heuristic(meerut,shimla,240).
heuristic(nagpur,shimla,1123).
heuristic(nasik,shimla,1279).
heuristic(panjim,shimla,1768).
heuristic(patna,shimla,988).
heuristic(pondicherry,shimla,2149).
heuristic(pune,shimla,1438).
heuristic(ranchi,shimla,1177).
heuristic(shillong,shimla,1563).
heuristic(shimla,shimla,0).
heuristic(surat,shimla,6402).
heuristic(trivandrum,shimla,2514).
heuristic(varanasi,shimla,859).
heuristic(vijayawada,shimla,1660).
heuristic(vishakapatnam,shimla,1611).
heuristic(agartala,surat,7984).
heuristic(agra,surat,6738).
heuristic(ahmedabad,surat,6620).
heuristic(allahabad,surat,7154).
heuristic(amritsar,surat,6192).
heuristic(asansol,surat,7672).
heuristic(bangalore,surat,7767).
heuristic(baroda,surat,6720).
heuristic(bhopal,surat,6974).
heuristic(bhubaneshwar,surat,7844).
heuristic(bombay,surat,6935).
heuristic(calcutta,surat,7860).
heuristic(calicut,surat,7763).
heuristic(chandigarh,surat,6397).
heuristic(cochin,surat,7904).
heuristic(coimbatore,surat,7874).
heuristic(delhi,surat,6574).
heuristic(gwalior,surat,6819).
heuristic(hubli,surat,7394).
heuristic(hyderabad,surat,7498).
heuristic(imphal,surat,8107).
heuristic(indore,surat,6895).
heuristic(jabalpur,surat,7177).
heuristic(jaipur,surat,6589).
heuristic(jamshedpur,surat,7680).
heuristic(jullundur,surat,6263).
heuristic(kanpur,surat,6965).
heuristic(kolhapur,surat,7221).
heuristic(lucknow,surat,6984).
heuristic(ludhiana,surat,6315).
heuristic(madras,surat,7966).
heuristic(madurai,surat,8047).
heuristic(meerut,surat,6591).
heuristic(nagpur,surat,7259).
heuristic(nasik,surat,6935).
heuristic(panjim,surat,7281).
heuristic(patna,surat,7390).
heuristic(pondicherry,surat,8022).
heuristic(pune,surat,7052).
heuristic(ranchi,surat,7571).
heuristic(shillong,surat,7896).
heuristic(shimla,surat,6402).
heuristic(surat,surat,0).
heuristic(trivandrum,surat,8071).
heuristic(varanasi,surat,7250).
heuristic(vijayawada,surat,7729).
heuristic(vishakapatnam,surat,7842).
heuristic(agartala,trivandrum,2288).
heuristic(agra,trivandrum,2080).
heuristic(ahmedabad,trivandrum,1681).
heuristic(allahabad,trivandrum,1954).
heuristic(amritsar,trivandrum,2582).
heuristic(asansol,trivandrum,1998).
heuristic(bangalore,trivandrum,504).
heuristic(baroda,trivandrum,1587).
heuristic(bhopal,trivandrum,1643).
heuristic(bhubaneshwar,trivandrum,1620).
heuristic(bombay,trivandrum,1256).
heuristic(calcutta,trivandrum,1984).
heuristic(calicut,trivandrum,332).
heuristic(chandigarh,trivandrum,2473).
heuristic(cochin,trivandrum,176).
heuristic(coimbatore,trivandrum,279).
heuristic(delhi,trivandrum,2242).
heuristic(gwalior,trivandrum,1974).
heuristic(hubli,trivandrum,788).
heuristic(hyderabad,trivandrum,1000).
heuristic(imphal,trivandrum,2556).
heuristic(indore,trivandrum,1586).
heuristic(jabalpur,trivandrum,1662).
heuristic(jaipur,trivandrum,2052).
heuristic(jamshedpur,trivandrum,1873).
heuristic(jullundur,trivandrum,2553).
heuristic(kanpur,trivandrum,2029).
heuristic(kolhapur,trivandrum,959).
heuristic(lucknow,trivandrum,2083).
heuristic(ludhiana,trivandrum,2495).
heuristic(madras,trivandrum,626).
heuristic(madurai,trivandrum,204).
heuristic(meerut,trivandrum,2282).
heuristic(nagpur,trivandrum,1426).
heuristic(nasik,trivandrum,1325).
heuristic(panjim,trivandrum,850).
heuristic(patna,trivandrum,2091).
heuristic(pondicherry,trivandrum,496).
heuristic(pune,trivandrum,1164).
heuristic(ranchi,trivandrum,1880).
heuristic(shillong,trivandrum,2471).
heuristic(shimla,trivandrum,2514).
heuristic(surat,trivandrum,8071).
heuristic(trivandrum,trivandrum,0).
heuristic(varanasi,trivandrum,1980).
heuristic(vijayawada,trivandrum,976).
heuristic(vishakapatnam,trivandrum,1234).
heuristic(agartala,varanasi,853).
heuristic(agra,varanasi,538).
heuristic(ahmedabad,varanasi,1088).
heuristic(allahabad,varanasi,118).
heuristic(amritsar,varanasi,1058).
heuristic(asansol,varanasi,441).
heuristic(bangalore,varanasi,1486).
heuristic(baroda,varanasi,1053).
heuristic(bhopal,varanasi,613).
heuristic(bhubaneshwar,varanasi,634).
heuristic(bombay,varanasi,1252).
heuristic(calcutta,varanasi,624).
heuristic(calicut,varanasi,1741).
heuristic(chandigarh,varanasi,856).
heuristic(cochin,varanasi,1854).
heuristic(coimbatore,varanasi,1716).
heuristic(delhi,varanasi,681).
heuristic(gwalior,varanasi,495).
heuristic(hubli,varanasi,1379).
heuristic(hyderabad,varanasi,1003).
heuristic(imphal,varanasi,1102).
heuristic(indore,varanasi,781).
heuristic(jabalpur,varanasi,393).
heuristic(jaipur,varanasi,738).
heuristic(jamshedpur,varanasi,429).
heuristic(jullundur,varanasi,989).
heuristic(kanpur,varanasi,296).
heuristic(kolhapur,varanasi,1321).
heuristic(lucknow,varanasi,266).
heuristic(ludhiana,varanasi,935).
heuristic(madras,varanasi,1392).
heuristic(madurai,varanasi,1789).
heuristic(meerut,varanasi,659).
heuristic(nagpur,varanasi,614).
heuristic(nasik,varanasi,1115).
heuristic(panjim,varanasi,1451).
heuristic(patna,varanasi,214).
heuristic(pondicherry,varanasi,1527).
heuristic(pune,varanasi,1209).
heuristic(ranchi,varanasi,320).
heuristic(shillong,varanasi,891).
heuristic(shimla,varanasi,859).
heuristic(surat,varanasi,7250).
heuristic(trivandrum,varanasi,1980).
heuristic(varanasi,varanasi,0).
heuristic(vijayawada,varanasi,1012).
heuristic(vishakapatnam,varanasi,847).
heuristic(agartala,vijayawada,1378).
heuristic(agra,vijayawada,1216).
heuristic(ahmedabad,vijayawada,1109).
heuristic(allahabad,vijayawada,1000).
heuristic(amritsar,vijayawada,1779).
heuristic(asansol,vijayawada,1037).
heuristic(bangalore,vijayawada,510).
heuristic(baroda,vijayawada,1009).
heuristic(bhopal,vijayawada,822).
heuristic(bhubaneshwar,vijayawada,690).
heuristic(bombay,vijayawada,867).
heuristic(calcutta,vijayawada,1054).
heuristic(calicut,vijayawada,784).
heuristic(chandigarh,vijayawada,1628).
heuristic(cochin,vijayawada,869).
heuristic(coimbatore,vijayawada,728).
heuristic(delhi,vijayawada,1394).
heuristic(gwalior,vijayawada,1107).
heuristic(hubli,vijayawada,599).
heuristic(hyderabad,vijayawada,246).
heuristic(imphal,vijayawada,1662).
heuristic(indore,vijayawada,851).
heuristic(jabalpur,vijayawada,742).
heuristic(jaipur,vijayawada,1258).
heuristic(jamshedpur,vijayawada,911).
heuristic(jullundur,vijayawada,1733).
heuristic(kanpur,vijayawada,1107).
heuristic(kolhapur,vijayawada,679).
heuristic(lucknow,vijayawada,1149).
heuristic(ludhiana,vijayawada,1672).
heuristic(madras,vijayawada,382).
heuristic(madurai,vijayawada,780).
heuristic(meerut,vijayawada,1419).
heuristic(nagpur,vijayawada,540).
heuristic(nasik,vijayawada,819).
heuristic(panjim,vijayawada,734).
heuristic(patna,vijayawada,1114).
heuristic(pondicherry,vijayawada,515).
heuristic(pune,vijayawada,751).
heuristic(ranchi,vijayawada,907).
heuristic(shillong,vijayawada,1542).
heuristic(shimla,vijayawada,1660).
heuristic(surat,vijayawada,7729).
heuristic(trivandrum,vijayawada,976).
heuristic(varanasi,vijayawada,1012).
heuristic(vijayawada,vijayawada,0).
heuristic(vishakapatnam,vijayawada,314).
heuristic(agartala,vishakapatnam,1072).
heuristic(agra,vishakapatnam,1182).
heuristic(ahmedabad,vishakapatnam,1261).
heuristic(allahabad,vishakapatnam,871).
heuristic(amritsar,vishakapatnam,1763).
heuristic(asansol,vishakapatnam,765).
heuristic(bangalore,vishakapatnam,807).
heuristic(baroda,vishakapatnam,1170).
heuristic(bhopal,vishakapatnam,868).
heuristic(bhubaneshwar,vishakapatnam,389).
heuristic(bombay,vishakapatnam,1108).
heuristic(calcutta,vishakapatnam,755).
heuristic(calicut,vishakapatnam,1082).
heuristic(chandigarh,vishakapatnam,1589).
heuristic(cochin,vishakapatnam,1150).
heuristic(coimbatore,vishakapatnam,1011).
heuristic(delhi,vishakapatnam,1363).
heuristic(gwalior,vishakapatnam,1081).
heuristic(hubli,vishakapatnam,907).
heuristic(hyderabad,vishakapatnam,512).
heuristic(imphal,vishakapatnam,1354).
heuristic(indore,vishakapatnam,952).
heuristic(jabalpur,vishakapatnam,697).
heuristic(jaipur,vishakapatnam,1278).
heuristic(jamshedpur,vishakapatnam,641).
heuristic(jullundur,vishakapatnam,1707).
heuristic(kanpur,vishakapatnam,1018).
heuristic(kolhapur,vishakapatnam,967).
heuristic(lucknow,vishakapatnam,1042).
heuristic(ludhiana,vishakapatnam,1647).
heuristic(madras,vishakapatnam,608).
heuristic(madurai,vishakapatnam,1031).
heuristic(meerut,vishakapatnam,1374).
heuristic(nagpur,vishakapatnam,583).
heuristic(nasik,vishakapatnam,1031).
heuristic(panjim,vishakapatnam,1037).
heuristic(patna,vishakapatnam,897).
heuristic(pondicherry,vishakapatnam,743).
heuristic(pune,vishakapatnam,1000).
heuristic(ranchi,vishakapatnam,662).
heuristic(shillong,vishakapatnam,1244).
heuristic(shimla,vishakapatnam,1611).
heuristic(surat,vishakapatnam,7842).
heuristic(trivandrum,vishakapatnam,1234).
heuristic(varanasi,vishakapatnam,847).
heuristic(vijayawada,vishakapatnam,314).
heuristic(vishakapatnam,vishakapatnam,0).








path_between(agartala,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad,indore,jaipur,kanpur,lucknow,madras,nagpur,nasik,panjim,patna,pondicherry,pune]).
path_between(agra,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad,indore,jaipur,kanpur,lucknow,madras,nagpur,nasik,panjim,patna,pondicherry,pune]).
path_between(ahmedabad,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad,indore,jaipur,kanpur,lucknow,madras,nagpur,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(allahabad,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(amritsar,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(asansol,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(bangalore,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(baroda,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(bhopal,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(bhubhneshwar,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(bombay,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(calcutta,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(calicut,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(chandigarh,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(cochin,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(coimbatore,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(delhi,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(gwalior,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(hubli,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(hyderabad,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(imphal,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(indore,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(jabalpur,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(jaipur,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(jamshedpur,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(jullundur,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(kanpur,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(kolhapur,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(lucknow,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(ludhiana,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(madras, [ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(meerut,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad,indore,jaipur,kanpur,lucknow,madras,nagpur,nasik,panjim,patna,pondicherry,pune]).
path_between(nagpur,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(nasik,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(panjim,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(patna,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(pondicherry,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin	,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(pune,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(ranchi,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(shillong,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(shimla,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(surat,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(trivandrum,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad	,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(varanasi,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(vijayawada,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad,indore,jaipur	,kanpur,lucknow	,madras,	nagpur	,nasik	,panjim	,patna	,pondicherry,pune]).
path_between(vishakapatnam,[ahmedabad,bangalore,bhubneshwar,bombay,calcutta,chandigarh,cochin,delhi,hyderabad,indore,jaipur,kanpur,lucknow	,madras,nagpur,nasik,panjim	,patna,pondicherry,pune]).
path_between(ahmedabad,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).
path_between(bangalore,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).
path_between(bhubaneshwar,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).
path_between(bombay,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).
path_between(calcutta,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).
path_between(chandigarh,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).
path_between(cochin,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).
path_between(delhi,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).
path_between(hyderabad,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).
path_between(indore,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).
path_between(jaipur,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).
path_between(kanpur,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).
path_between(lucknow,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).
path_between(madras,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).
path_between(nagpur,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).
path_between(nasik,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).
path_between(panjim,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).
path_between(patna,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).
path_between(pondicherry,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).
path_between(pune,[agartala,agra,ahmedabad,allahabad,amritsar,asansol,bangalore,baroda,bhopal,bhubaneshwar,bombay,calcutta,calicut,chandigarh,cochin,coimbatore,delhi,gwalior,Hubli,Hyderabad,Imphal,Indore,jabalpur,jaipur,jamshedpur,jullundur,kanpur,kolhapur,lucknow,ludhiana,madras,madurai,meerut,Nagpur,Nasik,panjim,patna,pondicherry,pune,Ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayawada,vishakapatnam]).






startBFSSearch(City1,City2):-
    bfs(City2,[[City1]],PQueue),
    findRouteCost(PQueue,0,[]).

bfs(C2,[[NewCity|PQueue]|_], [NewNode|PQueue]):-
    C2 =  NewCity,
    roaddist(C2,C2,_).

bfs(C2,[[NewCity|RemCity]|L],PQueue) :-
    bagof([City,NewCity,C|RemCity],
    (roaddist(City,NewCity,C), 
    \+ member(City,[NewCity|RemCity])),
    CreateNewL),
    append(VisitedNodes,CreateNewL,NewL),!,
    bfs(C2,NewL,PQueue);
    bfs(C2,L,PQueue).


findRouteCost([],PathCost,Route):-
	reverse(Route,NewRoute),
	write("Road Route taken is: "),
	listOfPlaces(NewRoute),nl,
	write("Cost of the path taken using depth first search: "),
	write(PathCost),nl.

findRouteCost([C|Rem],PathCost,Route):-
	number(C),
	NewPathCost is (PathCost + C),
    findRouteCost(Rem,NewPathCost,Route).
	
findRouteCost([C|Rem],PathCost,Route):-
	append(Route,[C],NewRoute),
	findRouteCost(Rem,PathCost,NewRoute).















startBFSSearch(City1,City2):-
    bfs(City2,[[City1]],PQueue),
    findRouteCost(PQueue,0,[]).

bfs(C2,[[NewCity|PQueue]|_], [NewNode|PQueue]):-
    C2 =  NewCity,
    roaddist(C2,C2,_).

bfs(C2,[[NewCity|RemCity]|L],PQueue) :-
    bagof([City,NewCity,C|RemCity],
    (roaddist(City,NewCity,C), 
    \+ member(City,[NewCity|RemCity])),
    CreateNewL),
    append(VisitedNodes,CreateNewL,NewL),!,
    bfs(C2,NewL,PQueue);
    bfs(C2,L,PQueue).


findRouteCost([],PathCost,Route):-
	reverse(Route,NewRoute),
	write("Road Route taken is: "),
	listOfPlaces(NewRoute),nl,
	write("Cost of the path taken using depth first search: "),
	write(PathCost),nl.

findRouteCost([C|Rem],PathCost,Route):-
	number(C),
	NewPathCost is (PathCost + C),
    findRouteCost(Rem,NewPathCost,Route).
	
findRouteCost([C|Rem],PathCost,Route):-
	append(Route,[C],NewRoute),
	findRouteCost(Rem,PathCost,NewRoute).















bestFirstSearch():-
	write("Below is the list of places to choose from to calculate the road route using the Best First Search algorithm: "),nl,
	listOfPlaces([ahmedabad,bangalore,bhubaneshwar,bombay,calcutta,chandigargh,coachin,delhi,hyderabad,indore,jaipur,kanpur,lucknow,madras,nagpur,nasik,panjim,patna,pondicherry,pune,agartala,agra,allahabad,amritsar,asansol,baroda,bhopal,calicut,coimbatore,gwalior,hubli,imphal,jabalpur,jamshedpur,jullundur,kohlapur,ludhiana,madurai,meerut,ranchi,shillong,shimla,surat,trivandrum,varanasi,vijayavada,vishakapatnam]),nl,
	write("Please enter a source city with a period from above option: "),
	read(C1),
	write("Please enter a destination city with a period from above option: "),
	read(C2),
	go(C1,C2).


go(C1,C2):-
	tavel_short(C1,C2,Route),
	write(Route).

tavel_short(Origin,Destination,Route):-
	search_bfs([[Origin]],Destination,Route).

search_bfs(PathQueue,End,Route):-
	PathQueue = [Route|_],
	last(Route,End).

search_bfs(PathQueue,End,SolutionPath):-
	PathQueue = [Route|Routes],
	last(Route,End),
	search_bfs(Routes,End,SolutionPath).

search_bfs(PathQueue,End,SolutionPath):-
	PathQueue = [Route|Routes],
	last(Route,Last),
	Last \= End,
	






























































































go(C1,C2):-
	tavel_short(C1,C2,Route),
	write(Route).

tavel_short(Origin,Destination,Route):-
	search_bfs([[Origin]],Destination,Route),
	write(Route).

search_bfs(PathQueue,End,Route):-
	PathQueue = [Route|_],
	last(Route,End).

search_bfs(PathQueue,End,SolutionPath):-
	PathQueue = [Route|Routes],
	last(Route,End),
	search_bfs(Routes,End,SolutionPath).

search_bfs(PathQueue,End,SolutionPath):-
	PathQueue = [Route|Routes],
	last(Route,Last),
	Last \= End,
	append_adjacents(Route,AugPaths),
	append(Routes,AugPaths,NewQueue),
	sort_by_distance(NewQueue,End,SortedQueue),
	search_bfs(SortedQueue,End,SolutionPath).

sort_by_distance([],_,[]).

sort_by_distance([X],_,[X]).

sort_by_distance([X|Xs],End,[Min|SortedXs]):-
	min_path([X|Xs],End,Min),
	delete([X|Xs],Min,RemovedMin),
	sort_by_distance(RemovedMin,End,SortedXs).

min_path([X],_,X).

min_path([X1|[X2|Xs]],End,Min):-
	cost(X1,End,C1),
	cost(X2,End,C2),
	C1 =< C2,
	min_path([X1|Xs],End,Min).

min_path([X1|[X2|Xs]],End,Min):-
	cost(X1,End,C1),
	cost(X2,End,C2),
	C1 > C2,
	min_path([X2|Xs],End,Min).

cost(P,End,C):-
	last(P,X),
	heuristic(X,End,C).

append_adjacents(Route,AugPaths):-
	last(Route,Last),
	path_between(Last,Adjs),
	append_all(Route,Adjs,AugPaths).

append_all(_,[],[]).

append_all(Route,[X|Xs],L):-
	member(X,Route),
	append_all(Route,Xs,L).

append_all(Route,[X|Xs],[AugPath|L]):-
	\+(member(X,Route)),
	append(Route,[X],AugPath),
	append_all(Route,Xs,L).



















