listOfSubjectsWithReqPreqCSE([solving_applied_mathematics,yes,yes,yes],["1. Machine Learning","2. Advanced Machine Learning","3. Deep Learning", "4. Computer Vision", "5. Natural Language Processing" ,"6. Artificial Intelligence"]).
listOfSubjectsWithReqPreqCSE([solving_applied_mathematics,no,no,no],["Sorry! But you need atleast one of the above prerequisites to take a subject from the selected domain!"]).
listOfSubjectsWithReqPreqCSE([solving_applied_mathematics,yes,no,no],["1. Probability and random process","2. Probability nd grahical model","3. Statistical Machine Learning"]).
listOfSubjectsWithReqPreqCSE([solving_applied_mathematics,no,yes,no],["1. Machine Learning","2. Theories of Deep Learning","3. Advanced Machine Learning","4. Deep Learning","5. Linear Optimization"]).
listOfSubjectsWithReqPreqCSE([solving_applied_mathematics,no,no,yes],["1. Artificial Intelligence","2. Machine Learning in Biomedical Applications"]).
listOfSubjectsWithReqPreqCSE([solving_applied_mathematics,yes,yes,no],["1. Statistical Machine Learning","2. Linear Optimization","3. Theories of Deep Learning","4. Probabilistic Graphical Models"]).
listOfSubjectsWithReqPreqCSE([solving_applied_mathematics,no,yes,yes],["1. Machine Learning","2. Theories of Deep Learning","3. Advanced Machine Learning","4. Deep Learning","5. Natural Language Processing","6. Artificial Intelligence"]).
listOfSubjectsWithReqPreqCSE([solving_applied_mathematics,yes,no,yes],["1. Probability and random process","2. Probability nd grahical model","3. Statistical Machine Learning","4. Artificial Intelligence"]).

listOfSubjectsWithReqPreqCSE([handling_data,yes,yes,yes],["1. Database System Implementation","2. Data Mining","3. Big Data Analytics", "4. Data Warehouse", "5. Database Methods in Information Retrieval"]).
listOfSubjectsWithReqPreqCSE([handling_data,no,no,no],["Sorry! But you need atleast one of the above prerequisites to take a subject from the selected domain!"]).
listOfSubjectsWithReqPreqCSE([handling_data,yes,no,no],["1. Database System Implementation","2. Database Methods in Information Retrieval","3. Data Warehouse"]).
listOfSubjectsWithReqPreqCSE([handling_data,no,yes,no],["1.Big Data Mining in Healthcare","2. Data Mining"]).
listOfSubjectsWithReqPreqCSE([handling_data,no,no,yes],["1. Data Analytics","2. Financial Data Analytics","3. Business Intelligence","Big Data Analytics"]).
listOfSubjectsWithReqPreqCSE([handling_data,yes,yes,no],["1. Database System Implementation","2. Data Warehouse","3. Introduction to Spatial Computing","4. Data Mining"]).
listOfSubjectsWithReqPreqCSE([handling_data,no,yes,yes],["1. Data Mining","2. Big Data Analytics","3. Web Intelligence and Big Data Analytics","4. Information integration and application"]).
listOfSubjectsWithReqPreqCSE([handling_data,yes,no,yes],["1. Data Mining","2. Distributed Data Mining","3. Data Warehouse","4. Business Intelligence and Data Warehousing"]).

listOfSubjectsWithReqPreqCSE([cyber_security_and_ethical_hacking,yes,yes],["1. Theory of Modern Cryptography","2. Fundations of Computer Security","3. Ethical Hacking","4. Network Security","5. Applied Cryptography"]).
listOfSubjectsWithReqPreqCSE([cyber_security_and_ethical_hacking,yes,no],["1. Topics is Cryptanalysis","2. Topics in Computer Security","3. Network Security","4. Network Anonymity and Privacy"]).

listOfSubjectsWithReqPreqCSE([mobile_computing_and_andriod_development,yes,yes],["1. Mobile Computing","2. Smart Sensing for internet of Things","3. Mobile and Cellular Network Security","4. Advanced Mobile Computing"]).
listOfSubjectsWithReqPreqCSE([mobile_computing_and_andriod_development,yes,no],["1. Cellular Data Networks","2. Network Security","3. Network Anonymity and Privacy"]).
listOfSubjectsWithReqPreqCSE([mobile_computing_and_andriod_development,no,yes],["1. Distributed Systems","2. Programming Cloud Services for mobile Applications"]).
listOfSubjectsWithReqPreqCSE([mobile_computing_and_andriod_development,no,no],["Sorry! But you need atleast one of the above prerequisites to take a subject from the selected domain!"]).

listOfSubjectsWithReqPreqCSE([theoritical_computer_science,yes,yes],["1. Randomnized Algorithm","2. Game Theory","3. Analysis and design of Algorithms","4. Quantum Computing"]).



listOfSubjectsWithReqPreqECE([cyber_physical_systems,yes,yes],["1. Wireless Communications","2. Wireless system implementation","3. Mobile Computing","4. Radar Systems"]).
listOfSubjectsWithReqPreqECE([cyber_physical_systems,no,no],["Sorry! But you need atleast one of the above prerequisites to take a subject from the selected domain!"]).
listOfSubjectsWithReqPreqECE([cyber_physical_systems,yes,no],["1. Wireless Communications","2. Wireless system implementation","3. Wireless Networks","4. Optical and Wireless Convergence for Beyond 5G and IoT"]).
listOfSubjectsWithReqPreqECE([cyber_physical_systems,no,yes],["1. Mobile Computing","2. Networked Control Systems"]).

listOfSubjectsWithReqPreqECE([machine_learning,yes,yes,yes],["1. Statistical Signal Processing","2. Probabilistic Graphical Models","3. Digital Image Processing","4. Speech and Audio Processing","5. Advanced Machine Learning"]).
listOfSubjectsWithReqPreqECE([machine_learning,yes,no,yes],["1. Statistical Signal Processing","2. Speech Recognition","3. Digital Image Processing","4. Speech and Audio Processing"]).
listOfSubjectsWithReqPreqECE([machine_learning,yes,yes,no],["1. Statistical Signal Processing","2. Speech Recognition","3. Digital Image Processing","4. Speech and Audio Processing"]).
listOfSubjectsWithReqPreqECE([machine_learning,yes,no,no],["Sorry! But you need atleast one of the above prerequisites to take a subject from the selected domain!"]).

listOfSubjectsWithReqPreqECE([vlsi_embedded_system,yes,yes],["1. Digital Verilog Design","2. Solid State Device","3. Advanced embedded system","4. Analog CMOS"]).




suggestChoice():-
	write('System : Do you have any plan of working in any of the following field?'),nl,
	write('System : a)Industry b)Academia c)None of the above'),nl,
	write("System : Instruction- Please type the corresponding choice with a period."),nl,
	write('You : '),read(Choice),nl,
	showChoice(Choice).

showChoice(a):-
	write('System : As you are planning to work in the industry, you might as well consider doing a Capstone project during your MTech.'),nl.

showChoice(b):-
	write('System : As you are planning to work in academics, you might as well consider doing a Thesis during your MTech..'),nl.

showChoice(c):-
	write('System : You might consider doing IP(Independant Project) during your MTech to get a hands-on experience.'),nl.




displayListOfSubject([]).

displayListOfSubject([H|T],L):-
	Y is L+1,
	write(H),
	nl,
	displayListOfSubject(T,Y).



suggestSubjectCSE(solving_applied_mathematics,Ans1,Ans2,Ans3):-
	write('System : You might like to take the following subjects as elective:'),nl,
	listOfSubjectsWithReqPreqCSE([solving_applied_mathematics,Ans1,Ans2,Ans3],ListOfSubjects),nl,
	(displayListOfSubject(ListOfSubjects,0);true),nl.

suggestSubjectCSE(handling_data,Ans1,Ans2,Ans3):-
	write('System : You might like to take the following subjects as elective:'),nl,
	listOfSubjectsWithReqPreqCSE([handling_data,Ans1,Ans2,Ans3],ListOfSubjects),nl,
	(displayListOfSubject(ListOfSubjects,0);true),nl.

suggestSubjectCSE(cyber_security_and_ethical_hacking,Ans1,Ans2):-
	write('System : You might like to take the following subjects as elective:'),nl,
	listOfSubjectsWithReqPreqCSE([cyber_security_and_ethical_hacking,Ans1,Ans2],ListOfSubjects),nl,
	(displayListOfSubject(ListOfSubjects,0);true),nl.

suggestSubjectCSE(mobile_computing_and_andriod_development,Ans1,Ans2):-
	write('System : You might like to take the following subjects as elective:'),nl,
	listOfSubjectsWithReqPreqCSE([mobile_computing_and_andriod_development,Ans1,Ans2],ListOfSubjects),nl,
	(displayListOfSubject(ListOfSubjects,0);true),nl.

suggestSubjectCSE(theoritical_computer_science,Ans1,Ans2):-
	write('System : You might like to take the following subjects as elective:'),nl,
	listOfSubjectsWithReqPreqCSE([theoritical_computer_science,Ans1,Ans2],ListOfSubjects),nl,
	(displayListOfSubject(ListOfSubjects,0);true),nl.




suggestSubjectECE(vlsi_embedded_system,Ans1,Ans2):-
	write('System : You might like to take the following subjects as elective:'),nl,
	listOfSubjectsWithReqPreqECE([vlsi_embedded_system,Ans1,Ans2],ListOfSubjects),nl,
	(displayListOfSubject(ListOfSubjects,0);true),nl.

suggestSubjectECE(machine_learning,Ans1,Ans2,Ans3):-
	write('System : You might like to take the following subjects as elective:'),nl,
	listOfSubjectsWithReqPreqECE([machine_learning,Ans1,Ans2,Ans3],ListOfSubjects),nl,
	(displayListOfSubject(ListOfSubjects,0);true),nl.

suggestSubjectECE(cyber_physical_systems,Ans1,Ans2):-
	write('System : You might like to take the following subjects as elective:'),nl,
	listOfSubjectsWithReqPreqECE([cyber_physical_systems,Ans1,Ans2],ListOfSubjects),nl,
	(displayListOfSubject(ListOfSubjects,0);true),nl.





checkPrequisiteCSE(solving_applied_mathematics):-
	write('System : Have you done any Probability & Statistics course?'),read(Opt1),nl,
	write('System : Have you done any Linear Aljebra course?'),read(Opt2),nl,
	write('System : Do you have any experience in programming?'),read(Opt3),nl,
	suggestSubjectCSE(solving_applied_mathematics,Opt1,Opt2,Opt3).

checkPrequisiteCSE(handling_data):-
	write('System : Have you done any DBMS course?'),read(Opt1),nl,
	write('System : Do you have any experience in programming?'),read(Opt2),nl,
	write('System : Are you interested in Data Analytics?'),read(Opt3),nl,
	suggestSubjectCSE(handling_data,Opt1,Opt2,Opt3).

checkPrequisiteCSE(cyber_security_and_ethical_hacking):-
	write('System : Have you done any Networking course?'),read(Opt1),nl,
	(Opt1 == no->
	 	write("System : Sorry! But you need Networking as a pre-requisite to pursue subjects in this domain."),nl
	;
	(Opt1 == yes->
		write('System : Do you have any experience in programming?'),read(Opt2),nl,
		suggestSubjectCSE(cyber_security_and_ethical_hacking,Opt1,Opt2)
	)).

checkPrequisiteCSE(mobile_computing_and_andriod_development):-
	write('System : Have you done any Networking course?'),read(Opt1),nl,
	write('System : Have you done any Operating System course?'),read(Opt2),nl,
	suggestSubjectCSE(mobile_computing_and_andriod_development,Opt1,Opt2).

checkPrequisiteCSE(theoritical_computer_science):-
	write('System : Have you done any Data Structure course?'),read(Opt1),nl,
	(Opt1 == no->
	 	write("System : Sorry! But you need Data Structure as a pre-requisite to pursue subjects in this domain."),nl
	;
	(Opt1 == yes->
		write('System : Have you done any Discrete Maths course?'),read(Opt2),nl,
		(Opt2 = no->
			write("System : Sorry! But you need Discrete Maths as a pre-requisite to pursue subjects in this domain."),nl
		;
		(Opt2 ==yes->
			suggestSubjectCSE(theoritical_computer_science,Opt1,Opt2)
		))
	)).





checkPrequisiteECE(vlsi_embedded_system):-
	write('System : Have you done any Mosfet course?'),read(Opt1),nl,
	(Opt1 == no->
	 	write("System : Sorry! But you need Data Structure as a pre-requisite to pursue subjects in this domain."),nl
	;
	(Opt1 == yes->
		write('System : Have you done any Combinational/Sequential circuit course?'),read(Opt2),nl,
		(Opt2 = no->
			write("System : Sorry! But you need Discrete Maths as a pre-requisite to pursue subjects in this domain."),nl
		;
		(Opt2 == yes->
			suggestSubjectECE(vlsi_embedded_system,Opt1,Opt2)
		))
	)).

checkPrequisiteECE(machine_learning):-
	write('System : Have you done any Signal and System course?'),read(Opt1),nl,
	(Opt1 == no->
	 	write("System : Sorry! But you need Signal and System as a pre-requisite to pursue subjects in this domain."),nl
	;
	(Opt1 == yes->
		write('System : Have you done any Probability course?'),read(Opt2),nl,
		write('System : Have you done any Linear Aljebra course?'),read(Opt3),nl,
		suggestSubjectECE(machine_learning,Opt1,Opt2,Opt3)
	)).

checkPrequisiteECE(cyber_physical_systems):-
	write('System : Have you done any Digital and Analog Communication course?'),read(Opt1),nl,
	write('System : Have you done any Networking course?'),read(Opt2),nl,
	suggestSubjectECE(cyber_physical_systems,Opt1,Opt2).




domainInterestCSE([]).

domainInterestCSE([H|T]):-
	write('System : Are you interested in '),write(H),write('?'),nl,
	write('System : Instruction- Please type yes/no with a period.'),nl,
	write('You : '),read(Input),nl,
	Input == yes,
	nb_getval(counter, C),
	CNew is C + 1,
	nb_setval(counter, CNew),!,
	write("System : Let's check the prequisite of the courses in this domain."),nl,
	write("System : Instruction- Please type yes/no with a period."),nl,
	checkPrequisiteCSE(H),
	(H == theoritical_computer_science->
		domainInterestCSE(T),
		true
	;
	(H \== theoritical_computer_science->
		write('System : Are you interested to explore more subjects in other domains?'),nl,
		write("System : Instruction- Please type yes/no with a period."),nl,
		write("You : "),read(X),nl,
		(X == yes->
			nb_setval(counter, 0),
			domainInterestCSE(T),
			true
		;
		(X == no->
			domainInterestCSE([]),
			true
		))
	)).

domainInterestCSE([H|T]):-
	domainInterestCSE(T).





domainInterestECE([]).

domainInterestECE([H|T]):-
	write('System : Are you interested in '),write(H),write('?'),nl,
	write('System : Instruction- Please type yes/no with a period.'),nl,
	write('You : '),read(Input),nl,
	Input == yes,
	nb_getval(counter, C),
	CNew is C + 1,
	nb_setval(counter, CNew),!,
	write("System : Let's check the prequisite of the courses in this domain."),nl,
	write("System : Instruction- Please type yes/no with a period."),nl,
	checkPrequisiteECE(H),
	(H == cyber_physical_systems->
		domainInterestECE(T),
		true
	;
	(H \== cyber_physical_systems->
		write('System : Are you interested to explore more subjects in other domains?'),nl,
		write("System : Instruction- Please type yes/no with a period."),nl,
		write("You : "),read(X),nl,
		(X == yes->
			nb_setval(counter, 0),
			domainInterestECE(T),
			true
		;
		(X == no->
			domainInterestECE([]),
			true
		))
	)).

domainInterestECE([H|T]):-
	domainInterestECE(T).


start:-
	write('.........................MTech Elective Advisory System............................'),nl,
	write("System : Hi, Let's help you in choosing the correct elective for a better career path."),nl,
	write('System : MTech has the following branches: mtechCSE, mtechECE, mtechCB'),nl,
    write('System: Instruction- Please type one of the three without any space and a period.'),nl,
	write('You : '),read(Branch),nl,
	(Branch == mtechCSE->
		mainMtechCSE(mtechCSE),
		true
	;
	(Branch == mtechECE->
		mainMtechECE(mtechECE),
		true
    ;
	(Branch == mtechCB->
		mainMtechCB(mtechCB),
		true
	))).


mainMtechCSE(mtechCSE):-
	nb_setval(counter, 0),
	write("System : Let's see what are your Domain Interests:- "),nl,
	domainInterestCSE([solving_applied_mathematics,handling_data,cyber_security_and_ethical_hacking,mobile_computing_and_andriod_development,theoritical_computer_science]),
	nb_getval(counter, CounterValue),
	(CounterValue == 0->
		write("System: The domain interest list has ended."),nl,
		write("System : If you have not been suggested an elective then you must select anyone of the above interest domains as all subjects of mtechCSE lie within them."),nl,
		true
	;
	(CounterValue == 1->
		suggestChoice(),
		true
	)),
	write("System : All the Interest Domains have been covered. Do you want to visit them all over again?"),nl,
	write('System : Instruction- Please type yes/no with a period.'),nl,
	write('You : '),read(Option),nl,
	(Option == yes->
		mainMtechCSE(mtechCSE),
		true
	;
	(Option == no->
		write('System : Thank You! Hope that the suggestions provided to you will turn out to be fruitful.'),
		true
	)).

mainMtechECE(mtechECE):-
	nb_setval(counter, 0),
	write("System : Let's see what are your Domain Interests:- "),nl,
	domainInterestECE([vlsi_embedded_system,machine_learning,cyber_physical_systems]),
	nb_getval(counter, CounterValue),
	(CounterValue == 0->
		write("System: The domain interest list has ended."),nl,
		write("System : If you have not been suggested an elective then you must select anyone of the above interest domains as all subjects of mtechECE lie within them."),nl,
		true
	;
	(CounterValue == 1->
		suggestChoice(),
		true
	)),
	write("System : All the Interest Domains have been covered. Do you want to visit them all over again?"),nl,
	write('System : Instruction- Please type yes/no with a period.'),nl,
	write('You : '),read(Option),nl,
	(Option == yes->
		mainMtechECE(mtechECE),
		true
	;
	(Option == no->
		write('System : Thank You! Hope that the suggestions provided to you will turn out to be fruitful.'),
		true
	)).

	

mainMtechCB(mtechCB):-
	write("System : You can pursue your elective subjects from the below list:- "),nl,
	write("1. Computational Gastronomy
		2. Machine Learning in Biomedical Applications
		3. Computing for Medicine
		4. Network Biology
		5. Computational MetaGenomics").